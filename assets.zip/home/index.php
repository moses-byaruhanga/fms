<?php 
include '../inc/header.php'; 
if(empty($_SESSION['user'])){
	//no display here
} 
else
{
	include '../inc/menu.php';
	$page = $_GET['page'];
	?>
	<main id="main" class="main">
		<?php 
		if($page != null){
			$redirect = '../inc/'.$page.".php";			
			if(file_exists($redirect)){
				include '../inc/'.$page.".php";
			}
			else{
				include '../inc/pages-error-404.html';
				$msg->failed("Page Not Found");
			}
		}
		?>
	</main><!-- End #main -->


	<!-- ======= Footer ======= -->
	<?php include '../inc/footer.php'; 
}
?>
