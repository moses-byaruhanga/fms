<?php
/**
 * 
 */
class DISPLAY
{
	
	function __construct($inter = "")
	{
		return "";
	}	
	//Encrypt the parameters
	function base64_url_encode($input){
		return strtr(base64_encode($input), '+/=', '-_,');
	}
	//Decrypt
	function base64_url_decode($input){
		return base64_decode(strtr($input, '-_,', '+/='));
	}
	function alert($type, $message){
		return '<div class="alert alert-'.$type.' alert-dismissible fade show" role="alert">
		<i class="bi bi-exclamation-octagon me-1"></i>
		'.$message.'
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>';
	}
	function load_account_number($name,$value="",$action = "",$attributes = "", $method="POST"){
		return '<div class="card">
		<div class="card-body">
		<h5 class="card-title">Enter Account Number</h5>
		<form class="row g-3" method="'.$method.'" action="'.$action.'">
		<div class="col-md-6">
		<div class="form-floating">
		<input type="text" class="form-control" id="accountno" name="accountno" placeholder="Account Number" value='.$value.'>
		<label for="accountno">Account Number</label>
		</div>
		</div>
		<div class="col-md-6">
		<button type="submit" '.$attributes.' name="'.$name.'" class="btn btn-primary btn-lg"><i class="bx bx-search-alt"></i> Find Member</button>	
		</div>		
		</form>
		</div>
		</div>';
	}
	function _table($title, $headers, $values, $rows=0){

		$table = '<div class="col-lg-12" style="font-size:14px;">
		<div class="card">
		<div class="card-body for-table" ondblclick="print()">
		<h5 class="card-title">'.$title.'</h5>
		<table class="table table-striped table-sm table-bordereless datatable">
		<thead>
		<tr id="head-row">';
		for($i=0; $i < count($headers); $i++){
			$table .= '<th scope="col">'.$headers[$i].'</th>';
		}
		$table .= '</tr></thead><tbody>
		';
		$rows = count($values) - 1;
		for($m=0; $m <= $rows; $m++){
			$table .= '<tr  valign="top">';
			for($j=0; $j < count($values[$m]); $j++){
				$table .= '<td>'.$values[$m][$j].'</td>';
			}
			$table .= '</tr>';
		}		
		$table .= '</tbody></table></div></div></div>'; 
		return $table;
	}
	function get_pagnation($baseUrl, $totalPages,$pageNumber){
		//Calculate previous and next pages 
		$prev = $pageNumber - 1;
		if($prev <= 0){
			$prev = 1;
		}
		$next = $pageNumber + 1;
		if($next >= $totalPages){
			$next = $totalPages;
		}
// Display pagination links 
		$output = '<nav aria-label="...">
		<ul class="pagination">
		<li class="page-item">
		<a class="page-link" href=\'?'.$baseUrl.'&view='.$prev.'\' tabindex="-1">Previous</a>
		</li>';
		if ($totalPages > 1) {	    		
			for ($i = 1; $i <= $totalPages; $i++) {
				$activeClass = $i == $pageNumber ? 'active' : '';			
				$output .= '			
				<li class="page-item '.$activeClass.'"><a class="page-link" href=\'?page=view-info&type=system-users&view='.$i.'\'>'.$i.'</a></li>		
				';       
			}	

			$output .= '
			<li class="page-item"><a class="page-link" href=\'?page=view-info&type=system-users&view='.$next.'\'>Next</a></li>
			</ul>
			</nav>
			';
		}
		if($totalPages <= 1){
			$output = "";
		}
		return $output;
	}
	function button_group($account = "", $url1 = "", $url2 = "", $url3 = ""){
		if($url3 != ""){
			$url3 = '&nbsp;                      
                <a class="btn btn-primary" href="'.$url3.'='.$this->base64_url_encode($account).'"><i class="bi bi-cash"></i></a>';
		}
		$output = '		
		<div class="btn-group" role="group">	
                <a href="'.$url1.'='.$this->base64_url_encode($account).'" class="btn btn-secondary"><i class="bi bi-pencil-square"></i></a>
                '.$url3.'

        
        &nbsp;                       
                <a class="btn btn-danger" href="'.$url2.'='.$this->base64_url_encode($account).'"><i class="bi bi-trash"></i></a>         
        
              </div>';
              return $output;
	}
	function deposit_withdraw_btn($accountno,$loan){
		if($loan != 0){
			$loan = '&nbsp;<a href="index.php?page=loan-repayment&account='.$this->base64_url_encode($accountno).'" class="btn btn-warning" title="Loan Repay"><i class="bi bi-cash" name="deposit-from-dashboard"></i></a>';
		}
		else{
			$loan = '';
		}
		$output = '		
		<div class="btn-group" role="group">
			
                <a href="index.php?page=savings&account='.$this->base64_url_encode($accountno).'" class="btn btn-success" title="Deposit"><i class="bi bi-plus-circle" name="deposit-from-dashboard"></i></a> 
                 
                '.$loan.'        
        &nbsp;             
                <a href="index.php?page=withdraw&account='.$this->base64_url_encode($accountno).'" class="btn btn-danger" title="Withdraw"><i class="bi bi-dash-circle"></i></a>
        
              </div>';
              return $output;
	}
	function notice($type, $head, $message, $footer){
		return '<div class="alert alert-'.$type.'  alert-dismissible fade show" role="alert">
                <h4 class="alert-heading">'.$head.'</h4>
                <p>'.$message.'</p>
                <hr>
                <p class="mb-0">'.$footer.'</p>
              </div>';
	}
	function add_button_monthly_payment($lable){
		return '
		<form method="POST">
		<button name="activate_monthly_payment" class="btn btn-primary rounded-pill"><i class="ri ri-add-fill"></i>&nbsp;'.$lable.'</button></form><br />';
	}
	function add_button($url,$lable){
		return '<a style="float: right;" href="'.$url.'" class="btn btn-primary rounded-pill"><i class="ri ri-add-fill"></i>&nbsp;'.$lable.'</a>';
	}
	function popup_button($target, $icon, $type,$name){
		return '<a style="float: right;" href="#" class="btn btn-'.$type.' btn-sm" data-bs-toggle="modal" data-bs-target="#'.$target.'"><i class="'.$icon.'">'.$name.'</i></a>';
	}
	function modal($head,$msg,$btn_name,$type,$icon,$btn_lable){
		return '<div class="modal fade" id="verticalycentered" tabindex="-1">
	<form method="POST">
                <div class="modal-dialog modal-dialog-centered">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">'.$head.'</h5>                      
                    </div>
                    <div class="modal-body">
                    '.$msg.'
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-'.$type.'" name="'.$btn_name.'"><i class="'.$icon.'"></i>'.$btn_lable.'</button>
                    </div>
                  </div>
                </div>
            </form>
              </div><!-- End Vertically';
	}
	function banck_card($account, $img, $branch, $balance){
		$card  = '<div class="col-md-3">
          <div class="card">
            <img src="../assets/img/bank/'.$img.'" height="221px" class="card-img-top" alt="...">
            <center>
            <div class="card-body">            
              <h6 class="card-title">'.$account.'</h6>      
              <span style="color:green;font-weight:500;">Account Balance: Shs '.$balance.'</span>
              <hr />
              <a href="index.php?page=bank-deposit&bank_account='.$this->base64_url_encode($account).'">Deposit</a> &nbsp; / &nbsp; <a href="index.php?page=bank-withdraw&bank_account='.$this->base64_url_encode($account).'"><font color="red">Withdraw</font></a>
              </center>
            </div>
          </div>';
          return $card;
	}
	
}

?>