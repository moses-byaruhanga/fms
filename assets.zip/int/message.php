<?php
##########Flag Messages#############
/**
 * 
 */
class MESSAGE
{
	
	function __construct($message="")
	{
		return "";
	}
	function success($message){
		echo '<div class="message-success">
		<div class="message-content">
		'.$message.'
		</div>
		</div>';
	}
	function failed($message){
		echo '<div class="message-failed">
		<div class="message-content">
		'.$message.'
		</div>
		</div>';
	}
	function breadcrumb($base, $page, $message = "Help comming soon..."){
	return '<div class="pagetitle">
      <h1>'.ucfirst($page).'</h1><button type="button" data-bs-toggle="modal" data-bs-target="#basicModal" class="btn btn-info"><i class="bi bi-info-circle"></i></button>
      <nav>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php?page=dashboard">Home</a></li>
          <li class="breadcrumb-item">'.$base.'</li>          
          <li class="breadcrumb-item active">'.$page.'</li>
        </ol>
      </nav>
    </div>
    <div class="modal fade" id="basicModal" tabindex="-1">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">'.ucfirst($page).' Help</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      '.$message.'
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>   
                    </div>
                  </div>
                </div>
              </div>
    ';
	}
}
?>