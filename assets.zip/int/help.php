<?php
/**
 * 
 */
class HELP
{	
	
	function __construct($help="")
	{
		return "";
	}
	function view_info($type){
		if($type == "system-users")
		{
		return '
		<b>To view</b> more listed users, click on the page number.
		<hr />
		If you wish to change/edit the users details, click on the eye (<i class="bi bi-eye"></i>) in the last column of the table (<b>action</b>), the edit form will open where you will change and save the details. 
		<hr />
		To delete/remove a user, click on the trash icon (<i class="bi bi-trash"></i>), in the last column of the table (<b>action</b>) and follow the prompts
		<hr />
		To <a href="index.php?page=add-user">add more users</a>, click on the add user button located on right hand of the table, the follow prompts.
		';
	}else if($type == "all-transactions"){
		return 'This page lists all the systems logs.
		<hr />
		Use the search box on the right hand side to filter the logs 
		<hr />
		To clear the logs, you must have logged in as a previllaged user eg admin. One that is done, the clear all system logs button will appear just above the search box.
		<hr />
		You can also extend the number of records shown by changing entries per page.
		';
	}
	elseif($type == "membership" || $type == "repository" || $type == "transactions"){
		return '
		This is the page where you view the '.$type.' statistics from the start of the sacco. <br />
		Hover the mouse on the type to see the total number<br />
		Click on the three dotted line on your right and select any other type of the graph as required.
		<hr>
		You can also download the graph by clicking on the three lines below the dotted lines and download the svg

		';
	}
	else
	{
		return 'Help Comming soon...';
	}
	}
	function add_users()
	{
		return '
		To add the user, fill in the form on this page and click save.
		';
	}
	function edit_members()
	{
		return '
		To edit the member details, fill in the form on this page and click save changes.
		';
	}
	function my_profile(){
		return 'This page shows information about you.
		<hr />
		You can change your full name by clicking the Edit Profile tab and save changes. 
		<hr />
		To change the password, click on change password tab and fill in the fieds and save changes
		<hr />
		You can also change your profile picture by clicking the icon (<i class="bi bi-upload"></i>) and follow prompts. To delete the profile picture, click on (<i class="bi bi-trash"></i>) and follow prompts.
		';
	}
	function add_member()
	{
		return '
         The members registration form helps in registering members to the sacco. The account number is autgenerated and follows a sequence as determined by the management.<br />
         Fill in all the fields and click add member to complete the process.
		';
	}
	function transfer_shares()
	{
		return '
		<h4>From Account Number</h4>		
		This is the default account. if you search accounts using the search form on this page, this will be treated as the from account. If you came to this page via a direct link from <a href="index.php?page=view-info&type=shares" target="new">view records</a>, then the from account is the accout of the member clicked against in the action. <br /><hr />
		<h4>To account Number</h4>
		
		This is entered manually in the from provided below. After the search, if the account is valid, the form appears. if you used a direct link to this page, the form is visible by defauls.
		<br /><hr />
		<h4>Share Amount</h4>
		
		This amount will be used to calculate the number of shares to be transfered. <b>The system takes 1 share equivalent to Shs 10000</b>.

		';
	}
	function import(){
		return '
		Make sure that the import files are <a href="https://www.bigcommerce.com/ecommerce-answers/what-csv-file-and-what-does-it-mean-my-ecommerce-business/" target="new">.csv</a>. Secondly, make sure that it is the format allowed by the template. Templates are attached on every import data type for downlaod. 

		';
	}
	function monthly_payments(){
		return '
		This is the amount deducted from every account at the beggining of every month of every year. This should be done once a month and most accurately on the 1st of the month. <br /><br />
		Note that when the date is not 1st yet or the amount has been deducted, the button for activating this function is not visible.
		';
	}
	
}
?>