<div class="card mb-3">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Welcome to FMS</h5>
                  </div>
                  <form method="POST" class="row g-3 needs-validation">

                    <div class="col-12">
                      <label for="Orgnisation Name" class="form-label">Orgnisation Name</label>
                      <div class="input-group has-validation">
                        <input type="text" name="org_name" class="form-control" id="org_name" required>
                      </div>
                    </div>

                    <div class="col-12">
                      <label for="Basic Color" class="form-label">Basic Color</label>
                      <div class="input-group has-validation">
                        <input type="text" name="basic_color" class="form-control" id="color" required>
                      </div>
                    </div>

                    <div class="col-12">
                      <label for="Admin Username" class="form-label">Admin Username</label>
                      <div class="input-group has-validation">
                        <input type="text" name="admin_username" class="form-control" id="user" required>
                      </div>
                    </div>

                    <div class="col-12">
                      <label for="Admin_Password" class="form-label">Admin Password</label>
                      <div class="input-group has-validation">
                        <input type="Password" name="Admin_Password" class="form-control" id="admin_pass" required>
                      </div>
                    </div>
                    <div class="col-12">
                      <label for="c_Admin_Password" class="form-label">Retype Password</label>
                      <div class="input-group has-validation">
                        <input type="Password" name="c_Admin_Password" class="form-control" id="c_admin_pass" required>
                      </div>
                    </div>
                    <div class="col-12">
                       <br />
                      <button name="save-btn" class="btn-save" type="submit">Save</button>
                    </div>
                  </form>

                </div>
              </div>