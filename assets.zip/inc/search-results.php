<?php echo $msg->breadcrumb("Search","Search Results");
$q = $_POST['query'];
?>
<div class="accordion" id="accordionExample">
			<div class="accordion-item">
				<h4 class="accordion-header" id="headingOne">
					<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
						System Users that matched '<?php echo $q; ?>'
					</button>
				</h4>
				<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
					<div class="accordion-body">

		<?php 
		$jsonData_q = $db->search("systemusers",$q,array("fullname","username","role","userFloat"));
		if($jsonData_q == "null"){
			echo $int->alert("info", "Sorry; there are no managers found!");		
		}
		else{
		$data_u = json_decode($jsonData_q, true);		
		$table_header = "List of Managers Matching";
		$head_row = array("#","fullname","username","role","userFloat");
		$j = 0;
		foreach ($data_u as $item) {
			$no = $j+1;			
			$individual_row[$j++] = array($no++,$item['fullname'],$item['username'],$item['role'],$item['userFloat']);
		}
		for($j=0;$j<count($data_u);$j++){
			$table_body[$j] = $individual_row[$j];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;
		}
		
		?>
</div>
</div>
</div>	


<br />

<div class="accordion-item">
				<h2 class="accordion-header" id="headingTwo">
					<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
						Members that matched '<?php echo $q; ?>'
					</button>
				</h2>
				<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
					<div class="accordion-body">

		
		<?php 
		$jsonData = $db->search("member",$q,array("surname","other_name","contact","accountno","address"));
		if($jsonData == "null"){
			echo $int->alert("info", "Sorry; there are no members found!");		
		}
		else{
		$data = json_decode($jsonData, true);		
		$table_header = "List of Members Matching";
		$head_row = array("#","accountno", "account_name", "contact", "address");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;			
			$individual_row[$i++] = array($no++,$item['accountno'],$item['surname']." ".$item['other_name'],$item['contact'],$item['address']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

		}
		
		?>		
</div>
</div>
</div>

<br />

<div class="accordion-item">
				<h2 class="accordion-header" id="headingThree">
					<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
						Transactions that matched '<?php echo $q; ?>'
					</button>
				</h2>
				<div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
					<div class="accordion-body">
		<?php 
		$jsonData = $db->search("userstrace",$q,array("accountno","user","accountname","amount","type","status"));
		if($jsonData == "null"){
			echo $int->alert("info", "Sorry; there are no transactions found!");		
		}
		else{
		$data = json_decode($jsonData, true);		
		$table_header = "List of Transactions Matching";
		$head_row = array("#","accountno","manager","accountname","amount","type","status");
		$m = 0;
		foreach ($data as $item) {
			$no = $m+1;			
			$individual_row[$m++] = array($no++,$item['accountno'],$item['user'],$item['accountname'],$item['amount'],$item['type'],$item['status']);
		}
		for($m=0;$m<count($data);$m++){
			$table_body[$m] = $individual_row[$m];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

		}
		
		?>

</div>
</div>
	</div>
</div>

