<?php echo $msg->breadcrumb("Members","Edit Details", $help->edit_members()); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){

}else{
	if(!empty($_GET['account'])){
		$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
	}
	$accountno = $_SESSION['account'];
	//get names
//Get the users details
$surname = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"surname"); 
$othernames = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"other_name"); 
$address = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"address");
$occupation = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"ocupation");
$gender  = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"gender"); 
if($gender == "M"){
	$gender = "Male";
}
else{
	$gender = "Female";
}
$nin  = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"personalnin");
$fee = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"registrationfee");
$contact = $db->_get("member", $db->_toString(array("accountno"),array($accountno)),"contact");
$s1name = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder1");
$s1Contact = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder1contact");
$s1nin = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder1nin");
$s2name = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder2");
$s2contact = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder2contact");
$s2nin = $db->_get("account", $db->_toString(array("accountno"),array($accountno)),"seconder2nin");
$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
	if($bal == "null"){
		$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
	}
 
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title"><?php echo $surname; ?> <?php echo $othernames; ?> | <?php echo $accountno; ?> | Bal: Shs <?php echo $bal; ?></h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingSurname" value="<?php echo $surname; ?>" name="surname">
					<label for="floatingSurname">Surname</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingOthernames" value="<?php echo $othernames; ?>" name="othernames">
					<label for="floatingOthernames">Other Name(s)</label>
				</div>
			</div>
			<!--EOF member name -->

			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAddres" value="<?php echo $address; ?>" name="address">
					<label for="floatingAddress">Address</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingOccupation" name="occupation" value="<?php echo $occupation; ?>">
					<label for="floatingOcupation">Occupation</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating mb-3">
					<select class="form-select" id="floatingSelect" aria-label="State" name="gender">	
					<option value="<?php echo $gender[0]; ?>" selected><?php echo $gender; ?></option>					
						<option value="M">Male</option>
						<option value="S">Female</option>
					</select>
					<label for="floatingSelect">Select Gender</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingnin" value="<?php echo $nin; ?>" name="nin">
					<label for="floatingnin">NIN</label>
				</div>
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" name="fees" class="form-control" id="floatingFees" value="<?php echo $fee; ?>">
					<label for="floatingFees">Shares/Reg. Fees (Shs)</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingContact" value="<?php echo $contact; ?>" name="contact">
					<label for="floatingContact">Contact</label>
				</div>
			</div>

			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS1Name" value="<?php echo $s1name; ?>" name="s1name">
					<label for="floatingS1Name">Seconder One (Full Name)</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS1Contact" value="<?php echo $s1Contact; ?>" name="s1contact">
					<label for="floatingS1Contact">Contact</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingnin" value="<?php echo $s1nin; ?>" name="s1nin">
					<label for="floatingnin">NIN</label>
				</div>
			</div>

			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingname" value="<?php echo $s2name; ?>" name="s2name">
					<label for="floatingname">Seconder Two (Full Name)</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingcontact" value="<?php echo $s2contact; ?>" name="s2contact">
					<label for="floatingcontact">Contact</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingnin" value="<?php echo $s2nin; ?>" name="s2nin">
					<label for="floatingnin">NIN</label>
				</div>
			</div>		
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="edit-member">Save Changes</button>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
		</form><!-- End floating Labels Form -->
	</div>
</div>
<?php } ?>