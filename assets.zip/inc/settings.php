<?php echo $msg->breadcrumb("Settings","System Settings");
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">
			Expand the settings type to change or add
		</h5>
		<div class="accordion" id="accordionExample">
			<div class="accordion-item">
				<h4 class="accordion-header" id="headingOne">
					<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
						Account Number Prefix
					</button>
				</h4>
				<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
					<div class="accordion-body">	
						<hr />This is the first characters added on the account number for new members. eg FIM, KIPT, MSD etc. Not that already registered members will not be affected by this change
						<hr />
						<form method="POST">
							<div class="col-md-12">								
								<div class="form-floating">
									<input type="text" class="form-control" id="floatingPrefix" name="prefix" value="<?php echo $db->_get("settings",$db->_toString(array("field"),array("accountNumberPrefix")),"value") ?>" placeholder="Prefix" required>
									<label for="floatingPrefix">Enter Prefix</label>
								</div>
							</div>
							<br />
							<div class="text-right">
								<button type="submit" class="btn btn-primary btn-lg" name="set_account_prefix"><i class="bx bxs-save"></i> Save Prefix Settings</button>			
							</form>
							<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a>					
						</div>

					</div>
				</div>
			</div>
			<div class="accordion-item">
				<h2 class="accordion-header" id="headingTwo">
					<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
						Monthly Payments
					</button>
				</h2>
				<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
					<div class="accordion-body">
						<hr />
						Enable Monthly payments of: (<span class="text-danger">This amount is deducted on every account number on every first of every month of the year</span>)
						<hr />
						<form method="POST">
							<input class="form-control" name="monthlypayment" type="text" placeholder="Enter amount in UGX" value="<?php echo $db->_get("settings",$db->_toString(array("field"),array("monthlyPayment")),"value") ?>" required>
							<br />
							<div class="text-right">
								<button type="submit" class="btn btn-primary btn-lg" name="save_monthly_payment"><i class="bx bxs-arrow-from-bottom"></i> Save Changes</button>			
							</form>
							<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></div>
						</div>
					</div>
				</div>
				<div class="accordion-item">
					<h2 class="accordion-header" id="headingThree">
						<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
							Minimum Account Balance
						</button>
					</h2>
					<div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
						<div class="accordion-body">
							<hr />Set the minimum account balance that remain on the account number.
							<hr />
							<form method="POST">								
								<input class="form-control" type="text" name="minimumBalance" value="<?php echo $db->_get("settings",$db->_toString(array("field"),array("minimumAccountBalance")),"value") ?>" required>
								<br />
								<div class="text-right">
									<button type="submit" class="btn btn-primary btn-lg" name="save_minimum_account_bal"><i class="bx bxs-save"></i> Save Changes</button>	
									<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></form></div>
								</div>
							</div>

