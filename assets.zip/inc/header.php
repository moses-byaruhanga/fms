<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FMS</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/fms_style.css" rel="stylesheet">
  <link href="../assets/css/msg.css" rel="stylesheet">
</head>
<?php
###########Header Form############
$timeout = 60*30;
ini_set( "session.gc_maxlifetime", $timeout );
ini_set( "session.cookie_lifetime", $timeout );
session_start();
$s_name = session_name();

include '../int/interface.php';
$int = new DISPLAY();
if(empty($_SESSION['user']) || !isset( $_COOKIE[ $s_name ] )){
  echo $int->alert("danger", "Your session has expired or you are not authorised to access this page, kindly loggin to access!");
  echo "<meta http-equiv='refresh' content='3; url=../index.php'>";
}
else{
  setcookie( $s_name, $_COOKIE[ $s_name ], time() + $timeout, '/' );
  include '../int/message.php';
  include '../int/help.php';
  $msg = new MESSAGE();
  $help = new HELP();
  include '../db/fn.php';
  $db = new DataBase();
  $org_name = $db->_get("basic_info",$db->_toString(array("id"),array("1")),"organisation_name");
  $user = $_SESSION['user'];
  $role = $_SESSION['role'];
  $name = $_SESSION['name'];
  $float = $_SESSION['float'];
  $st = $_SESSION['st'];
  $ft = $_SESSION['ft'];
  $profile = "../assets/img/profile/".$db->_get("systemusers",$db->_toString(array("username"),array($user)),"profile");;

//get spacific user info
  $query = "user = '".$user."' AND datetime >= CURDATE()";
  $trans_no = $db->_count("userstrace",$query);
  $float = $db->_get("systemusers",$db->_toString(array("username"),array($user)),"userFloat");
  //initialize members details
  $surname = "Surname";
  $othernames = "Othernames";
  $accountno = "AccountNo";
  $bal = "----";
  $address = "";
  $contact = "";
  $data_table = "";
  $loanBal = "";
?>
<body>
 <?php include '../php/action.php'; 
 ?>
 <!-- ======= Header ======= -->
 <header id="header" class="header fixed-top d-flex align-items-center">

  <div class="d-flex align-items-center justify-content-between">
    <a href="index.php?page=dashboard" class="logo d-flex align-items-center">
      <img src="../assets/img/logo.png" alt="">
      <span class="d-none d-lg-block"><?php echo $user; ?></span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div><!-- End Logo -->

  <div class="search-bar">
    <form class="search-form d-flex align-items-center" method="POST" action="index.php?page=search-results">
      <input type="text" name="query" placeholder="Search" title="Enter search keyword" required>
      <button type="submit" title="Search"><i class="bi bi-search"></i></button>
    </form>
  </div><!-- End Search Bar -->

  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

      <li class="nav-item d-block d-lg-none">
        <a class="nav-link nav-icon search-bar-toggle " href="#">
          <i class="bi bi-search"></i>
        </a>
      </li><!-- End Search Icon-->

      <li class="nav-item dropdown">

        <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
          <i class="bi bi-cash-coin"></i>
          <span class="badge bg-success badge-number">
            <?php echo $trans_no; ?>
          </span>       
        </a><!-- End Notification Icon -->

        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
          <li class="dropdown-header">
            Float: Shs: <?php echo $float; ?>
            <a href="index.php?page=view-info&type=all-userstrace&filter=All"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
          </li>

          <?php echo $db->get_trans_brief($user); ?>

        <li>
          <hr class="dropdown-divider">
        </li>
        <li class="dropdown-footer">
          <a href="index.php?page=view-info&type=all-userstrace&filter=All">Show all transactions</a>
        </li>

      </ul><!-- End Notification Dropdown Items -->

    </li><!-- End Notification Nav -->

    <li class="nav-item dropdown pe-3">

      <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">      
        <?php echo '<img src="'.$profile.'" alt="Profile" class="rounded-circle">';  ?>
        <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $user; ?></span>
      </a><!-- End Profile Iamge Icon -->

      <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
        <li class="dropdown-header">
          <h6><?php echo $name; ?></h6>
          <span>(<?php echo $role; ?>)</span>
        </li>
        <li>
          <hr class="dropdown-divider">
        </li>

        <li>
          <a class="dropdown-item d-flex align-items-center" href="index.php?page=my-profile">
            <i class="bi bi-person"></i>
            <span>My Profile</span>
          </a>
        </li>
        <li> 
        <li>
            <hr class="dropdown-divider">
          </li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="index.php?page=settings">
              <i class="bi bi-gear"></i>
              <span>System Settings</span>
            </a>
          </li> 
          <li>
            <hr class="dropdown-divider">
          </li>

          <li>
            <a class="dropdown-item d-flex align-items-center" href="index.php?page=logout">
              <i class="bi bi-box-arrow-right"></i>
              <span>Sign Out</span>
            </a>
          </li>

        </ul><!-- End Profile Dropdown Items -->
      </li><!-- End Profile Nav -->

    </ul>
  </nav><!-- End Icons Navigation -->
</header><!-- End Header -->
<?php } ?>
