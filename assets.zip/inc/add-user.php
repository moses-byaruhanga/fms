<?php echo $msg->breadcrumb("System Users","Add User"); ?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">Register System User</h5>
		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingName" name="fullname" placeholder="Enter Full Name" required>
					<label for="floatingName">Enter Full Name</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingusername" name="username" placeholder="Enter Username" required>
					<label for="floatingusername">Select a Username</label>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-floating mb-3">
					<select class="form-select" id="floatingSelect" name="role" aria-label="State">						
						<option value="Manager" selected>Manager</option>
						<option value="Admin">Admin</option>
					</select>
					<label for="floatingSelect">Select the Role</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="password" class="form-control" id="floatingpass" name="password" placeholder="Enter Password" required>
					<label for="floatingpass">Enter Password</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="password" class="form-control" id="floatingpass" name="c_password" placeholder="Enter Password" required>
					<label for="floatingpass">Confirm Password</label>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="add-user">Register User</button>
				<a href="index.php?page=view-info&type=system-users" class="btn btn-success btn-lg">Back</a>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
		</form>
</div>
</div>
