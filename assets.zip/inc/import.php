<?php echo $msg->breadcrumb("Data","Import",$help->import());
?>
<?php if($data_table == ""){ ?>
	<div class="card">
		<div class="card-body">
			<h5 class="card-title">
				Select the data type to import below
			</h5>
			<div class="accordion" id="accordionExample">
				<div class="accordion-item">
					<h4 class="accordion-header" id="headingOne">
						<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							Members
						</button>
					</h4>
					<div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
						<div class="accordion-body">	
							<hr />Please click on the choose file and choose a .csv file in the format of this <a href="../assets/templates/members.csv"> template</a>
							<hr />
							<form method="POST" enctype="multipart/form-data">
								<input type="hidden" value="member" name="table">
								<input class="form-control" type="file" name="file" id="formFile">
								<br />
								<div class="text-right">
									<button type="submit" class="btn btn-primary btn-lg" name="import_data_members"><i class="bx bxs-arrow-from-bottom"></i> Upload Data</button>			
								</form>
								<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a>					
							</div>

						</div>
					</div>
				</div>
				<div class="accordion-item">
					<h2 class="accordion-header" id="headingTwo">
						<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							Managers/Users Transactions
						</button>
					</h2>
					<div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
						<div class="accordion-body">
							<hr />Please click on the choose file and choose a .csv file in the format of this <a href="../assets/templates/transactions.csv"> template</a>
							<hr />
							<form method="POST" enctype="multipart/form-data">
								<input type="hidden" value="userstrace" name="table">
								<input class="form-control" name="file" type="file" id="formFile">
								<br />
								<div class="text-right">
									<button type="submit" class="btn btn-primary btn-lg" name="import_data_transactions"><i class="bx bxs-arrow-from-bottom"></i> Upload Data</button>			
								</form>
								<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></div>
							</div>
						</div>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header" id="headingThree">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Members Transactions
							</button>
						</h2>
						<div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<hr />Please click on the choose file and choose a .csv file in the format of this <a href="../assets/templates/members_transactions.csv"> template</a>
								<hr />
								<form method="POST" enctype="multipart/form-data">
									<input type="hidden" value="hist" name="table">
									<input class="form-control" type="file" id="formFile" name="file">
									<br />
									<div class="text-right">
										<button type="submit" class="btn btn-primary btn-lg" name="import_data_hist"><i class="bx bxs-arrow-from-bottom"></i> Upload Data</button>	
									<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></form></div>
								</div>
							</div>						
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header" id="headingFour">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
								Members Net Account Balances
							</button>
						</h2>
						<div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<hr />Please click on the choose file and choose a .csv file in the format of this <a href="../assets/templates/members_balances.csv"> template</a>
								<hr />
								<form method="POST" enctype="multipart/form-data">
									<input type="hidden" value="currentt" name="table">
									<input class="form-control" type="file" id="formFile" name="file">
									<br />
									<div class="text-right">
										<button type="submit" class="btn btn-primary btn-lg" name="import_data_balances"><i class="bx bxs-arrow-from-bottom"></i> Upload Data</button>			
									</form>
									<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></div>
								</div>
							</div>
						</form>
					</div>
					<div class="accordion-item">
						<h2 class="accordion-header" id="headingFive">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								Loan Details
							</button>
						</h2>
						<div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
							<div class="accordion-body">
								<hr />Please click on the choose file and choose a .csv file in the format of this <a href="../assets/templates/loan.csv"> template</a>
								<hr />
								<form method="POST" enctype="multipart/form-data">
									<input type="hidden" value="loan" name="table">
									<input class="form-control" type="file" id="formFile" name="file">
									<br />
									<div class="text-right">
										<button type="submit" class="btn btn-primary btn-lg" name="import_data_loan"><i class="bx bxs-arrow-from-bottom"></i> Upload Data</button>			
									</form>
									<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php } else {
			echo '<div class="card">
			<div class="card-body"><br />';	

			echo $int->alert("warning", "This data has not been added yet to the system. If you cancel the import, no changes will be made to the system.")."<hr></div>".$data_table;
			echo '
			<div class="col-md-12">
			<form method="POST">
			&nbsp;&nbsp;<button type="submit" class="btn btn-primary btn-lg" name="confirm_import_data"><i class="bx bxs-arrow-from-bottom"></i> Confirm Import</button>			
			<a href="index.php?page=import" class="btn btn-secondary btn-lg"> Cancel and Go Back</a></form></div><br />
			</div></div>

			';
	
 } 
?>