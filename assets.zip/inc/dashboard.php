<?php 
echo $msg->breadcrumb("Dashboard","dashboard");
//The filter for transactions
unset($_SESSION['account']);
if(empty($_GET['transFilter'])){
  $transFilter = "Today";
}
else
{
  $transFilter = $_GET['transFilter'];
} 
if($transFilter == "" || $transFilter == "All"){
	$cond = "";
	$cond1 = $db->_toString(array("type"),array("Savings"));
	$cond2 = $db->_toString(array("type"),array("Withdraws"));
	$cond3 = $db->_toString(array("type"),array("Loan Payment"));
}
elseif($transFilter == "Today"){
	$cond = "datetime >= CURDATE()";
	$cond1 = $db->_toString(array("type"),array("Savings"))." AND ".$cond;
	$cond2 = $db->_toString(array("type"),array("Withdraws"))." AND ".$cond;
	$cond3 = $db->_toString(array("type"),array("Loan Payment"))." AND ".$cond;
}
else{
	$cond = "datetime >= CURDATE() AND user = '".$transFilter."'";
	$cond1 = $db->_toString(array("type"),array("Savings"))." AND ".$cond;
	$cond2 = $db->_toString(array("type"),array("Withdraws"))." AND ".$cond;
	$cond3 = $db->_toString(array("type"),array("Loan Payment"))." AND ".$cond;

}

?>
<section class="section dashboard">
	<div class="row">
		<!-- Left side columns -->
		<div class="col-lg-8">
			<div class="row">

				<!-- Sales Card -->
				<div class="col-xxl-4 col-md-6">
					<div class="card info-card sales-card">
						<div class="filter">
							<a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
							<ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
								<li class="dropdown-header text-start">
									<h6><?php echo $transFilter; ?></h6>
								</li>

								<li><a class="dropdown-item" href="index.php?page=dashboard&transFilter=All">All</a></li>
								<li><a class="dropdown-item" href="index.php?page=dashboard&transFilter=Today">Today</a></li>
								<?php echo $db->getUsersList(); ?>
								<hr class="dropdown-divider"/>
								 <li class="dropdown-footer">
								<?php echo '
								<a href="index.php?page=view-info&type=all-userstrace&filter='.$transFilter.'">View all</a>'; ?>
								</li>
							</ul>
						</div>

						<div class="card-body">
							<h5 class="card-title">Total Transations <span>| <?php echo $transFilter; ?></span></h5>

							<div class="d-flex align-items-center">
								<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
									<i class="bi bi-cash"></i>
								</div>
								<div class="ps-3">
									<h6><?php
									echo $db->_count("userstrace",$cond);
									 ?></h6>
									<span class="text-success small pt-1 fw-bold">S: <?php
									echo $db->_count("userstrace",$cond1);
									 ?></span> | 
									 <span class="text-danger small pt-1 fw-bold">W: <?php
									echo $db->_count("userstrace",$cond2);
									 ?></span> 
									 |
									 <span class="text-primary small pt-1 fw-bold">L: <?php
									echo $db->_count("userstrace",$cond3);
									 ?></span>

								</div>
							</div>
						</div>

					</div>
				</div><!-- End Sales Card -->

				<!-- Revenue Card -->
				<div class="col-xxl-4 col-md-6">
					<div class="card info-card revenue-card">
						<div class="card-body">
							<h5 class="card-title">My Float (Shs)</h5>

							<div class="d-flex align-items-center">
								<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
									<i class="bi bi-currency-dollar"></i>
								</div>
								<div class="ps-3">
									<h6><?php
									echo $db->_get("systemusers",$db->_toString(array("username"),array($user)), "userFloat");
									 ?>/=</h6>
									 <a href="index.php?page=dashboard">
									<span class="text-success small pt-1 fw-bold">Refresh</span></a>
								</div>
							</div>
						</div>

					</div>
				</div><!-- End Revenue Card -->

				<!-- Customers Card -->
				<div class="col-xxl-4 col-xl-12">

					<div class="card info-card customers-card">
						<div class="card-body">
							<h5 class="card-title">Total Membbers</h5>

							<div class="d-flex align-items-center">
								<div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
									<i class="bi bi-people"></i>
								</div>
								<div class="ps-3">
									<h6><?php
									echo $db->_count("member");
									 ?></h6>
									<span class="text-success small pt-1 fw-bold">Male:</span> <span class="text-muted small pt-2 ps-1"><?php
									echo $db->_count("member",$db->_toString(array("gender"),array("male")));
									 ?></span>
									 |
									<span class="text-success small pt-1 fw-bold">Female:</span> <span class="text-muted small pt-2 ps-1"><?php
									echo $db->_count("member",$db->_toString(array("gender"),array("Female")));
									 ?></span>

								</div>
							</div>

						</div>
					</div>

				</div><!-- End Customers Card -->

				<!-- Recent Sales -->
				<div class="col-12">			
<?php
$condition = "`user` = '".$user."' ORDER BY `times` DESC LIMIT 30"; //add on condition
$jsonData = $db->get_data("frequent", array("accountno"), $condition);
if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no members yet to display here 
			<hr />");
	}
	else
	{
		$data = json_decode($jsonData, true);
		$table_header = "Frequent Members";
		$head_row = array("#","Name", "address", "contact", "accountno","Action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			//get loan info
			$loan = 0;
			$loanCond = "`accountno` = '".$item['accountno']."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
		if($loanBal != "null"){
			$loan = 1;
		}
			$name = $db->member($item['accountno'],"surname")." ".$db->member($item['accountno'],"other_name"); 
			$address = $db->member($item['accountno'],"address");
			$contact = $db->member($item['accountno'],"contact");	
			$individual_row[$i++] = array($no++,$name,$address,$contact,$item['accountno'], $int->deposit_withdraw_btn($item['accountno'],$loan));
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;
	}
?>
</div><!-- End Recent Sales -->

<!-- End Top Selling -->

			</div>
		</div><!-- End Left side columns -->

		<!-- Right side columns -->
		<div class="col-lg-4">

			<!-- Recent Activity -->
			<div class="card">
				<div class="filter">
					<a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
					<ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
						<li class="dropdown-header text-start">
							<h6>Filter</h6>
						</li>

						<li><a class="dropdown-item" href="index.php?page=dashboard&filter=Savings">Savings</a></li>
						<li><a class="dropdown-item" href="index.php?page=dashboard&filter=Withdraws">Withdraws</a></li>
						<li><a class="dropdown-item" href="index.php?page=dashboard&filter=Loan Payment">Loan Payment</a></li>
						<li><a class="dropdown-item" href="index.php?page=dashboard&filter=Logged In">Login</a></li>
						<li><a class="dropdown-item" href="index.php?page=dashboard&filter=Other">Rest/Other</a></li>
					</ul>
				</div>

				<div class="card-body">
					<h5 class="card-title">Recent Transactions <span>| <?php 
						if(empty($_GET['filter'])){echo "All";}else{echo $_GET['filter'];} ?></span></h5>

					<div class="activity">
						<?php 
						if(empty($_GET['filter'])){
							$filter = "all";
						}
						else{
							$filter = $_GET['filter'];
						}
						echo $db->get_recent_activity($filter, 10, 1,$user); ?>
					</div>
					<hr /><a href="index.php?page=view-info&type=all-transactions"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
				</div>
			</div><!-- End Recent Activity -->
		</div><!-- End Right side columns -->

	</div>
</section>