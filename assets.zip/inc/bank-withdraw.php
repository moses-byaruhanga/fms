<?php echo $msg->breadcrumb("Bank","Add Bank Withdraw"); 
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">Add Bank Withdraw</h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<?php 
			if(isset($_GET['bank_account'])){
				echo '<div class="col-md-12">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAmount" value="'.$int->base64_url_decode($_GET['bank_account']).'" name="accountno" required>
					<label for="floatingAmount">Account Number</label>
				</div>
			</div>';
			}
			else{
			echo $db->_input_select("accountno","bank","accountno","accountno","",$required="required", $more = "", $brackate_value="name"); 
		}
			?>
						
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control"  placeholder="Amount" name="amount" required>
					<label for="floatingAmount">Amount (Shs)</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="date" class="form-control" name="trans_date" required>
					<label for="floatingDate">Transaction Date</label>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-warning btn-lg" name="add_bank_withdraw">Save Withdraw</button>
				<a href="index.php?page=view-info&type=bank" class="btn btn-secondary btn-lg">Back</a>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>