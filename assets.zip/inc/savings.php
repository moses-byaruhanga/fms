<?php echo $msg->breadcrumb("Transactions","Savings"); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){

}else{
	if(!empty($_GET['account'])){
		$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
	}
	$accountno = $_SESSION['account'];
	$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
	$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
	$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
	$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
	$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
	if($bal == "null"){
		$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
	}
?>


<!--Print Form for found member -->
<div class="card">
	<div class="card-body">
		<h5 class="card-title"><?php echo $surname; ?> <?php echo $othernames; ?> | <?php echo $accountno; ?> | <font color="green">Bal: Shs <?php echo $bal; ?></font> | <font color="red">LoanBal: Shs <?php echo $loanBal; ?></font></h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<?php echo '<input type="text" class="form-control" id="floatingAddress" placeholder="Address" value="'.$address.'"  readonly>'; ?>
					<label for="floatingAddress">Address</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingAmount" placeholder="Amount" name="amount" required>
					<label for="floatingAmount">Amount (Shs)</label>
				</div>		
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<?php echo '<input type="text" class="form-control" id="floatingContact" placeholder="Contact" value="'.$contact.'" readonly>'; ?>
					<label for="floatingContact">Contact</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="receipt_no" placeholder="Receipt Number" name="receiptno" required>
					<label for="receipt_no">Receipt Number</label>
				</div>		
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="deposit">Deposit Now</button>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>
<?php } ?>