<?php echo $msg->breadcrumb("Statistics",str_replace("-", " ", $_GET['data']), $help->view_info($_GET['data'])); 
if(empty($_GET['g_type'])){
	$g_type = "pie";
}
else
{
    $g_type = $_GET['g_type'];
}
$stats_data = "";
//get stats
if($_GET['data'] == "repository"){
	$stats_data = "".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"mainbalance").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"mainwithdraws").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"mainsavings").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"dailywithdraw").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"dailysaving").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"maincharges").",".$db->_get("repository",$db->_toString(array("`s/n`"),array("1")),"dailycharges");
	$lables = "'mainbalance', 'mainwithdraws', 'mainsavings', 'dailywithdraw', 'dailysaving', 'maincharges', 'dailycharges'";
}
elseif($_GET['data'] == "membership"){
	$male = $db->_count("member",$db->_toString(array("gender"),array("male")));

	$female = $db->_count("member",$db->_toString(array("gender"),array("female")));
	$total = $male + $female;
	$stats_data = "".$female.",".$male;
	$lables = "'Female', 'Male'";
}
elseif($_GET['data'] == "transactions")
{
	$stats_data = "".$db->_count("transactions",$db->_toString(array("trans_type"),array("Withdraws"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Savings"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Loan Payment"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Logged In"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Logged Out"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Member Registration"))).",".
	$db->_count("transactions",$db->_toString(array("trans_type"),array("Repository Updates")));
	;
	$lables = "'Withdraw', 'Savings', 'Loan Repayment', 'Logged In', 'Logged Out', 'Member Registration','Repository Updates'";
}

//detect graph
if($g_type == "bar"){
	$stats_data = "{data:[".$stats_data."]}";
}

$url = $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
<!-- Reports -->
          <div class="row">
            <div class="col-12">            	
              <div class="card">
                <div class="card-body">
                	<div class="filter" style="float: right;">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>
                    <li><a class="dropdown-item" href="<?php echo $url; ?>&g_type=bar">Bar Graph</a></li>
                    <li><a class="dropdown-item" href="<?php echo $url; ?>&g_type=donut">Donut Graph</a></li>
                    <li><a class="dropdown-item" href="<?php echo $url; ?>&g_type=polarArea">Polar Graph</a></li>
                    <li><a class="dropdown-item" href="<?php echo $url; ?>&g_type=pie">Pie Chart</a></li>
                  </ul>
                </div>
                  <h5 class="card-title">Graph <span>/ <?php echo $g_type; ?></span></h5>


                  <!-- Line Chart -->

              <!-- Bar Chart -->
               <!-- Pie Chart -->
              <div id="pieChart"></div>

              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new ApexCharts(document.querySelector("#pieChart"), {
                    series: [<?php echo $stats_data; ?>],
                    chart: {
                      height: 350,
                      type: '<?php echo $g_type; ?>',
                      toolbar: {
                        show: true
                      }
                    },
                    labels: [<?php echo $lables; ?>]
                  }).render();
                });
              </script>
              <!-- End Bar CHart -->

                </div>

              </div>
            </div>