<?php echo $msg->breadcrumb("Loan","My Loan"); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){

}else{
	if(!empty($_GET['account'])){
		$_SESSION['account'] = $_GET['account'];
	}
	$accountno = $_SESSION['account'];
	$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
	$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
	$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
	$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
	$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
	$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
	if($bal == "null"){
		$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
	}
	//get LoanBal
	$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
		if($loanBal == "null"){
			$loanBal = 0;
		}
	$tbhd = '<h5 class="card-title">'.$surname.' '.$othernames.' | '.$accountno.' | <font color="green">Bal: Shs '.$bal.'</font> | <font color="red">LoanBal: Shs '.$loanBal.'</font></h5>';
	$cond = "`accountno` = '".$_SESSION['account']."' ORDER BY `s/n` DESC";
	$data = $db->get_data("payment", array("paymentdate", "paidamount", "balance", "loanstatus", "receiptno", "times"), $cond);
	if($data == "null"){
		echo $int->alert("info", "Sorry; there are no transactions yet!");		
	}
	else{
		$data = json_decode($data, true);
		$head_row = array("#","paymentdate", "paidamount", "balance", "loanstatus", "receiptno", "times");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$individual_row[$i++] = array($no++,$item['paymentdate'],$item['paidamount'],$item['balance'],$item['loanstatus'],$item['receiptno'],$item['times']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($tbhd,$head_row,$table_body);
		echo $table;

	}
}
?>