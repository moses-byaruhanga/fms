<div class="card mb-3">
 <div class="card-body">

  <div class="pt-4 pb-2">
    <h5 class="card-title text-center pb-0 fs-4">Login to Your Account</h5>
  </div>
  <form method="POST" class="row g-3 needs-validation">

    <div class="col-12">
     <label for="yourUsername" class="form-label">Username</label>
     <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend"><i class="bx bxs-lock"></i></span>
      <input type="text" name="username" class="form-control" id="yourUsername" required>
    </div>
  </div>
<!--yourPassword-->
  <div class="col-12">
     <label for="yourUsername" class="form-label">Password</label>
     <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend"><i class="bx bxs-key"></i></span>
      <input type="password" name="password" class="form-control" id="yourUsername" required>
    </div>
  </div>
  <div class="col-12">
    <br />
    <button name="login-btn" class="btn btn-success" type="submit">Login</button>
  </div>
</form>

</div>
</div>