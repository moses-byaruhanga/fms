<?php echo $msg->breadcrumb("Members","Delete Member"); 
echo "<div class='card'>
	<div class='card-body'>
		<h5 class='card-title'>Completely Delete Member</h5>";
if(isset($_GET['account'])){
	$_SESSION['account'] = $_GET['account'];
	$names = $db->_get("deleted", $db->_toString(array("accountno"),array($_SESSION['account'])),"surname")." ".$db->_get("deleted", $db->_toString(array("accountno"),array($_SESSION['account'])),"other_name");
	if($names == "null null"){
		echo $int->notice("danger","The member has been deleted or the account is invalid!","","<a href='index.php?page=view-info&type=trash'>Go Back</a>");
	}
	else{
	echo $int->notice("danger", "Delete ".$names, "You are about to delete ".$names."; Plese note that this action can not be undone!", "<form method='POST' class='row g-3'><div class='col-md-12'><div class='form-floating'><input type='password' class='form-control' id='floatingPass' placeholder='Enter Your Password' name='user_pass'>
					<label for='floatingPass'>Enter Your Password To Confirm</label></div></div><div class='col-md-12'><div class='form-floating'><button type='submit' class='btn btn-danger btn-lg' name='completely-delete-member'><i class='bi bi-trash'></i> Completely Delete Member</button>&nbsp;&nbsp;&nbsp;<a href='index.php?page=view-info&type=trash' class='btn btn-success btn-lg'>Cancel & Go Back</a></div></div></form>");
}

}
else{
	echo $int->alert("danger", "Please Select the user to delete; Plese note that this action can not be undone!");
	?>	
	<form class="row g-3" method="GET">
		<input type="hidden" name="page" value="delete-user">
		<?php
	echo $db->_input_select("id","systemusers","username","id","");
	?>
						
			<div class="col-md-6"><button type="submit" class="btn btn-danger btn-lg" name="delete-user-select"><i class='bi bi-trash'></i> Continue</button>
			<a href="index.php?page=view-info&type=system-users" class="btn btn-success btn-lg">Cancel & Go Back</a>
			</div>
			</div>
</form>
	<?php
}
echo "</div></div>";
?>