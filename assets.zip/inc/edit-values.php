<?php echo $msg->breadcrumb("Data","Edit Values"); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){
	//unset($_SESSION['account']);
	//show nonthing here
}
else if(!empty($_GET['account'])){
	$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
}
if(empty($_SESSION['account'])){
	//show nothing
}
else 
{
	$accountno = $_SESSION['account'];
	$names = $db->_get("member", $db->_toString(array("accountno"),array($_SESSION['account'])),"surname")." ".$db->_get("member", $db->_toString(array("accountno"),array($_SESSION['account'])),"other_name");
	if($names == "null null"){
		$msg->failed("This account do not exist, or deleted");
	}
	if(isset($_GET['extend_period'])){
		?>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Changing Repayment Date for <?php echo $names; ?>'s Loan</h5>
						<form method="POST">
							<hr />
					<div class="form-floating">
							<input type="date" class="form-control" id="floatingAmount" placeholder="Amount" name="repaymentDate" required>
							<label for="floatingAmount">Enter New Date</label>
					</div>
					<hr />
					<div class="text-right">
						<button type="submit" class="btn btn-primary btn-lg" name="save_change_loan_date"><i class="bi bi-save"></i> Save</button>
						<a href="index.php?page=edit-values&account=<?php echo $int->base64_url_encode($_SESSION['account']); ?>" class="btn btn-secondary btn-lg">Go Back</a>
					</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
	else{
		//get the details of the member
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
		if($bal == "null"){
			$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
		}
		$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
	$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
	$loanDate = $db->_get("loan",$loanCond,"repaymentdate"). " | <a href='index.php?page=edit-values&extend_period=true'>Change</a>";
	if($loanBal == "null"){
		$loanBal = 0;
		$loanDate = "N/A";
	}
	$fine = $db->get_loan_fine($accountno);
	$contact = $db->_get("member", $db->_toString(array("accountno"),array($_SESSION['account'])),"contact");

?>
<!--Print Form for found member -->
<div class="row">
<div class="col-md-6">
	<div class="card">
		<div class="card-body">
			<h5 class="card-title">Editing/Changing <?php echo $names; ?>'s Values</h5>
			<?php 
			echo "Account Balance: Shs <font color=green>". $bal."</font><br /><hr />";
			echo "Loan Balance: Shs <font color=red>". $loanBal."</font><br /><hr />";
			echo "Loan Repayment Date: <font color=pink>". $loanDate."</font><br /><hr />";
			echo "Loan Balance Fine: Shs <font color=red>". $fine."</font><br /><hr />";
			echo "contact: <font color=blue>". $contact."</font><br /><hr />";
			?>
				
		</div>
	</div>
</div>
<div class="col-md-6">
	<div class="card">
		<div class="card-body"><br />
			<form method="POST">
				<div class="form-floating">
					<select id="floatingSelect" name="filed" class="form-select" id="select"required>
						<option value="" selected disabled>Select Option</option>
						<option value="acumulatedamount">Account Balance</option>
						<option value="repaymentamount">Loan Balance</option>
						<option value="contact">Contact</option>
					</select>
					<label for="floatingSelect">Select Field To Change</label>
					<hr />
					<div class="form-floating">
							<input type="text" class="form-control" id="floatingAmount" placeholder="Amount" name="value" required>
							<label for="floatingAmount">Value</label>
					</div>
					<hr />
					<div class="text-right">
						<button type="submit" class="btn btn-primary btn-lg" name="save_edit_values"><i class="bi bi-save"></i> Save</button>
						<a href="index.php?page=dashboard" class="btn btn-secondary btn-lg">Go Back</a>
					</div>
				</div>
			</form>				
		</div>
	</div>
</div>
</div>
<?php 
	} 
}

?>