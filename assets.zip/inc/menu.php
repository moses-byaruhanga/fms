<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php?page=dashboard">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->
       <li class="nav-item">
        <a class="nav-link " href="index.php?page=all-links">
          <i class="bi bi-book"></i>
          <span>All Links</span>
        </a>
      </li>
     <li class="nav-heading">Basic Menu</li>
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-menu-button-wide"></i><span>Transactions</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=savings">
              <i class="bi bi-circle"></i><span>Savings</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=withdraw">
              <i class="bi bi-circle"></i><span>Withdraw</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=view-info&type=transactions">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>          
        </ul>
      </li><!-- End Components Nav -->
      <?php if($role == "Admin"){ ?>
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#managers" data-bs-toggle="collapse" href="#">
          <i class="bi bi-envelope"></i><span>Managers</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="managers" class="nav-content collapse " data-bs-parent="#sidebar-nav">          
          <li>
            <a href="index.php?page=view-info&type=system-users">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=view-info&type=all-userstrace&filter=All">
              <i class="bi bi-circle"></i><span>View User Trans.</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cash-in">
              <i class="bi bi-circle"></i><span>Cash In</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=delete-user">
              <i class="bi bi-circle"></i><span style="color:red;">Delete User</span>
            </a>
          </li>
          </ul>
      </li> <?php } ?>

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-journal-text"></i><span>Member</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">          
          <li>
            <a href="index.php?page=view-info&type=members">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=add-member">
              <i class="bi bi-circle"></i><span>Add Member</span>
            </a>
          </li>
            <?php if($role == "Admin"){
              echo '
              <li>
            <a href="index.php?page=monthly-payment">
              <i class="bi bi-circle"></i><span>Monthly Payments</span>
            </a>
          </li> 
              
              <li>
            <a href="index.php?page=edit-details">
              <i class="bi bi-circle"></i><span>Edit Details</span>
            </a>
          </li>          

              <li><a href="index.php?page=dissmiss-member">
              <i class="bi bi-circle"></i><span><font color="red">Dismiss Member</font></span>
            </a>
          </li>';
        }
            ?>
                    
        </ul>
      </li><!-- End Forms Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bar-chart"></i><span>Statistics</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=stats&data=repository">
              <i class="bi bi-circle"></i><span>General Repository</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=stats&data=membership">
              <i class="bi bi-circle"></i><span>Membership</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=stats&data=transactions">
              <i class="bi bi-circle"></i><span>Transactions</span>
            </a>
          </li>
        </ul>
      </li><!-- End Tables Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-envelope"></i><span>Loan</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=view-info&type=loan">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=loan-application">
              <i class="bi bi-circle"></i><span>Add Loan</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=loan-repayment">
              <i class="bi bi-circle"></i><span>Loan Repayment</span>
            </a>
          </li>         
          
          <li>
            <a href="index.php?page=my-loan">
              <i class="bi bi-circle"></i><span>Individual Loan Details</span>
            </a>
          </li>
          <?php if($role == "Admin"){
            echo '<li>
            <a href="index.php?page=delete-loan">
              <i class="bi bi-circle"></i><span><font color="red">Delete Loan Details</font></span>
            </a>
          </li>';
          }?>
        </ul>
      </li><!-- End Charts Nav -->
      

      <li class="nav-heading">Data & Backup</li>
      <!-- Begin Data Nav -->
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#data-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-dash-circle"></i><span>Data</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="data-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=view-info&type=trash">
              <i class="bi bi-circle"></i><span>Trash Can</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=import">
              <i class="bi bi-circle"></i><span>Import</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=export">
              <i class="bi bi-circle"></i><span>Export</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=edit-values">
              <i class="bi bi-circle"></i><span>Edit Values</span>
            </a>
          </li>
        </ul>
      </li><!-- End Data Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#backup-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-file-earmark"></i><span>Backup</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="backup-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=main-system-data">
              <i class="bi bi-circle"></i><span>Main System Data</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=archive">
              <i class="bi bi-circle"></i><span>Archive</span>
            </a>
          </li>
        </ul>
      </li><!-- End Backup Nav -->

      <li class="nav-heading">Shares</li>
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#shares-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-layout-text-window-reverse"></i><span>Basic Actions</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="shares-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=view-info&type=shares">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>
          <?php if($role == "Admin"){
            echo '
          <li>
            <a href="index.php?page=add-share">
              <i class="bi bi-circle"></i><span>Add Share(s)</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=remove-share">
              <i class="bi bi-circle"></i><span>Remove Share(s)</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=transfer-share">
              <i class="bi bi-circle"></i><span>Transfer Share(s)</span>
            </a>
          </li>';
        }
          ?>
        </ul>
      </li><!-- End Shares Nav -->
      <li class="nav-heading">Incomes & Expenditures</li>
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-cash" data-bs-toggle="collapse" href="#">
          <i class="bi bi-cash"></i><span>Cash Flows</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-cash" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=view-info&type=cashflows">
              <i class="bi bi-circle"></i><span>View Info</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cashinflow">
              <i class="bi bi-circle"></i><span>Add Cash Inflow</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cashoutflow">
              <i class="bi bi-circle"></i><span>Add Cash Outflow</span>
            </a>
          </li>          
        </ul>
      </li><!-- End Balancing Nav -->
      <li class="nav-heading">External Accounts</li>
      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-bank" data-bs-toggle="collapse" href="#">
          <i class="bi bi-bank"></i><span>Bank Information</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-bank" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?page=view-info&type=bank">
              <i class="bi bi-circle"></i><span>List Banks</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=add-bank">
              <i class="bi bi-circle"></i><span>Add Bank Account</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=bank-deposit">
              <i class="bi bi-circle"></i><span>Add Bank Deposit</span>
            </a>
          </li> 
          <li>
            <a href="index.php?page=bank-withdraw">
              <i class="bi bi-circle"></i><span>Add Bank Withdraw</span>
            </a>
          </li> 
          <li>
            <a href="index.php?page=view-info&type=bank-transactions">
              <i class="bi bi-circle"></i><span>View Transactions</span>
            </a>
          </li>        
        </ul>
      </li><!--End of Banks-->
    </ul>
  </aside>