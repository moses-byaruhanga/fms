<?php echo $msg->breadcrumb("Users","Cash In"); 
echo "<div class='card'>
	<div class='card-body'>
		<h5 class='card-title'>Cash In</h5>";
if(isset($_GET['id'])){
	$_SESSION['id'] = $int->base64_url_decode($_GET['id']);
	$float = $names = $db->_get("systemusers", $db->_toString(array("ID"),array($_SESSION['id'])),"userFloat");
	$names = $db->_get("systemusers", $db->_toString(array("ID"),array($_SESSION['id'])),"fullname");
	echo $int->notice("info", "Cash In From ".$names." | Current Float: Shs ".$float, "You are about to cash in from ".$names."; Plese note that this action can not be undone!", "<form method='POST' class='row g-3'><div class='col-md-6'><div class='form-floating'><input type='password' class='form-control' id='floatingPass' placeholder='Enter Your Password' name='user_pass'>
					<label for='floatingPass'>Enter Your Password To Confirm</label></div></div>
					<div class='col-md-6'><div class='form-floating'><input type='number' class='form-control' id='floatingAmount' placeholder='Enter Cash in Amount' name='cashinamount'>
					<label for='floatingAmount'>Enter Cash In Amount (Shs): Leave Blank for all</label></div></div>
					<div class='col-md-6'><div class='form-floating'><button type='submit' class='btn btn-warning btn-lg' name='cash-in-user'><i class='bi bi-cash'></i> Cash In</button>&nbsp;&nbsp;&nbsp;<a href='index.php?page=view-info&type=system-users' class='btn btn-success btn-lg'>Cancel & Go Back</a></div></div></form>");

}
else{
	echo $int->alert("info", "Please Select the user to cash in; Plese note that this action can not be undone!");
	?>	
	<form class="row g-3" method="GET">
		<input type="hidden" name="page" value="cash-in">
		<?php
	echo $db->_input_select("id","systemusers","username","ID","");
	?>
						
			<div class="col-md-6"><button type="submit" class="btn btn-warning btn-lg" name="delete-user-select"><i class='bi bi-cash'></i> Continue to Cash In</button>
			<a href="index.php?page=view-info&type=system-users" class="btn btn-success btn-lg">Cancel & Go Back</a>
			</div>
			</div>
</form>
	<?php
}
echo "</div></div>";
?>