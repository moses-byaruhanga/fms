<?php echo $msg->breadcrumb("Users","Delete User"); 
echo "<div class='card'>
	<div class='card-body'>
		<h5 class='card-title'>Delete User</h5>";
if(isset($_GET['id'])){
	$_SESSION['id'] = $_GET['id'];
	$names = $db->_get("systemusers", $db->_toString(array("ID"),array($_SESSION['id'])),"fullname");
	echo $int->notice("danger", "Delete ".$names, "You are about to delete ".$names."; Plese note that this action can not be undone!", "<form method='POST' class='row g-3'><div class='col-md-12'><div class='form-floating'><input type='password' class='form-control' id='floatingPass' placeholder='Enter Your Password' name='user_pass'>
					<label for='floatingPass'>Enter Your Password To Confirm</label></div></div><div class='col-md-6'><div class='form-floating'><button type='submit' class='btn btn-danger btn-lg' name='delete-user'><i class='bi bi-trash'></i> Delete User</button>&nbsp;&nbsp;&nbsp;<a href='index.php?page=view-info&type=system-users' class='btn btn-success btn-lg'>Cancel & Go Back</a></div></div></form>");

}
else{
	echo $int->alert("danger", "Please Select the user to delete; Plese note that this action can not be undone!");
	?>	
	<form class="row g-3" method="GET">
		<input type="hidden" name="page" value="delete-user">
		<?php
	echo $db->_input_select("id","systemusers","username","ID","");
	?>
						
			<div class="col-md-6"><button type="submit" class="btn btn-danger btn-lg" name="delete-user-select"><i class='bi bi-trash'></i> Continue</button>
			<a href="index.php?page=view-info&type=system-users" class="btn btn-success btn-lg">Cancel & Go Back</a>
			</div>
			</div>
</form>
	<?php
}
echo "</div></div>";
?>