<?php echo $msg->breadcrumb("Members","Add Member", $help->add_member()); 
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">Members Registration Form</h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingSurname" name="surname" placeholder="Surname" required>
					<label for="floatingSurname">Surname</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingOthernames" name="other_name" placeholder="Other Name(s)" required>
					<label for="floatingOthernames">Other Name(s)</label>
				</div>
			</div>
			<!--EOF member name -->

			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAddres" name="address" placeholder="Address" required>
					<label for="floatingAddress">Address</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingOccupation" name="occupation" placeholder="Occupation" required>
					<label for="floatingOcupation">Occupation</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating mb-3">
					<select class="form-select" id="floatingSelect" name="type" aria-label="State">						
						<option value="M" selected>Member</option>
						<option value="S">Share Holder</option>
						<option value="T">Temprary Member</option>
					</select>
					<label for="floatingSelect">Select Member Type</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating mb-3">
					<select class="form-select" id="floatingSelect" name="gender" aria-label="Gender">						
						<option value="M" selected>Male</option>
						<option value="S">Female</option>
					</select>
					<label for="floatingSelect">Select Gender</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="Date" class="form-control" id="floatingDate" name="dob" placeholder="Date" required>
					<label for="floatingDate">Birth Date</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingNin" name="nin" placeholder="NIN" required>
					<label for="floatingNin">NIN</label>
				</div>
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" name="fees" class="form-control" id="floatingShares" placeholder="Shares/Reg. Fees" required>
					<label for="floatingShares">Shares/Reg. Fees (Shs)</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingContact" name="contact" placeholder="Contact" required>
					<label for="floatingContact">Contact</label>
				</div>
			</div>

			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" name="s1name" class="form-control" id="floatingS1name" placeholder="Seconder One (Full Name)" required>
					<label for="floatingS1name">Seconder One (Full Name)</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" name="S1contact" class="form-control" id="floatingS1contact" placeholder="Contact" required>
					<label for="floatingS1contact">Contact</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS1nin" name="S1nin" placeholder="NIN" required>
					<label for="floatingS1nin">NIN</label>
				</div>
			</div>

			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS2name" name="S2name" placeholder="Seconder two Full Name" required>
					<label for="floatingDate">Seconder Two (Full Name)</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS2contact" name="S2contact" placeholder="Contact" required>
					<label for="floatingS2contact">Contact</label>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingS2nin" name="S2nin" placeholder="NIN" required>
					<label for="floatingS2nin">NIN</label>
				</div>
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" name="accountno" class="form-control" id="floatingAccountno" placeholder="Account Number" readonly value="(Auo-Generated)">
					<label for="floatingAccountno">Account Number</label>
				</div>
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingDeposit" name="deposit" placeholder="Initial Deposit" required>
					<label for="floatingDeposit">Initial Deposit (Shs)</label>
				</div>
			</div>			
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="add-member">Add Member</button>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
		</form><!-- End floating Labels Form -->

	</div>
</div>
<!--Auto generate the account Number -->
<script type="text/javascript">
	
</script>