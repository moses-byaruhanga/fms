<?php echo $msg->breadcrumb("Loan","Loan Application"); 
echo $int->load_account_number("load_account");
if($surname != "Surname"){
if($loanBal > 0){
	//display info
		$msg->failed("Member still has unpaid loan");
		echo $int->notice("danger",$surname." ".$othernames, "This member still has a loan of Shs: ".$loanBal, "<a href=''>View Loan Repayment Transactions</a>");
}	
else{
?>
		<!--Loan Application Form -->
		<div class="card">
	<div class="card-body">
		<h5 class="card-title"><?php echo $surname; ?> <?php echo $othernames; ?> | <?php echo $accountno; ?> | <font color="green">Bal: Shs <?php echo $bal; ?></font> | <font color="red">LoanBal: Shs <?php echo $loanBal; ?></font></h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingApplicationFees" name="loanApplicationFees" placeholder="Loan Application Fees" required>
					<label for="floatingApplicationFees">Loan Application Fees</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingAmount" placeholder="Loan Amount" name="amount" required>
					<label for="floatingAmount">Loan Amount (Shs)</label>
				</div>		
			</div>

			<div class="col-md-6">
				<div class="form-floating">
					<input type="numebr" name="interestRate" class="form-control" id="floatingInterestRate" placeholder="Interest Rate (%)" value="12"  required>
					<label for="floatingInterestRate">Interest Rate (%)</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="numebr" name="FineRate" class="form-control" id="floatingInterestFineRate" placeholder="Fine Rate (%)" value="10"  required>
					<label for="floatingFineRate">Fine Rate (%)</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="date" class="form-control" id="floatingDate" placeholder="Repayment Date" name="repaymentDate" required>
					<label for="floatingDate">Repayment Date</label>
				</div>		
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" name="receiptNo" class="form-control" id="floatingReceipt" placeholder="Receipt Number" required>
					<label for="floatingReceipt">Receipt Number</label>
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="newloan">Add New Loan</button>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>
<?php } }else{

} ?>
