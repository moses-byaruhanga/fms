<?php echo $msg->breadcrumb("Bank","Add Bank Account"); 
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">Add Bank Account</h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST" enctype="multipart/form-data">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAmount" placeholder="Bank Name" name="name" required>
					<label for="floatingAmount">Name of Bank</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAmount" placeholder="Main Brach" name="main-brach" required>
					<label for="floatingAmount">Main Branch</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAmount" placeholder="Account Number" name="accountno" required>
					<label for="floatingAmount">Acount Number</label>
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control"  placeholder="Amount" name="amountBalance" required>
					<label for="floatingAmount">Acount Balance (Shs)</label>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-floatin">
					<span>Upload Logo</span>
					<input type="file" class="form-control" id="floatingAmount"  name="logo" required>					
				</div>
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="add_bank">Save</button>
				<a href="index.php?page=view-info&type=bank" class="btn btn-secondary btn-lg">Back</a>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>