<?php 
echo $msg->breadcrumb("System Navigation","All Links"); 


?>
<style type="text/css">
	ul>li{
		padding: 6px;
	}
</style>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">
			List of all the basic system links
		</h5>
		<ul>			
			<li><a href="index.php?page=savings">Savings</a></li>
			<li><a href="index.php?page=withdraw">Withdraw</a></li>
			<li><a href="index.php?page=loan-repayment">Loan Repayment</a></li>
			<li><a href="index.php?page=view-info&type=transactions">View Members Transactions</a></li>
			<li><a href="index.php?page=view-info&type=members">View Members' Records</a></li>
		<?php if($role == "Admin"){ ?>
			<li>
            <a href="index.php?page=view-info&type=system-users">
              <span>View Managers Records</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=view-info&type=all-userstrace&filter=All">
              <span>View Managers Transactions</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cash-in">
              <span>Cash In</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=delete-user">
              <span style="color:red;">Delete Manager</span>
            </a>
          </li>
      </li> <?php } ?>
      <li>
      	<a href="index.php?page=add-member">
              Add Member</span>
            </a>
          </li>
            <?php if($role == "Admin"){
              echo '
              <li>
            <a href="index.php?page=monthly-payment">
              Monthly Payments</span>
            </a>
          </li> 
              
              <li>
            <a href="index.php?page=edit-details">
              Edit Details</span>
            </a>
          </li>          

              <li><a href="index.php?page=dissmiss-member">
              <font color="red">Dismiss Member</font></span>
            </a>
          </li>';
        }
            ?>
        <li>
            <a href="index.php?page=stats&data=repository">
              General Repository Statistics</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=stats&data=membership">
              Membership Statistics</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=stats&data=transactions">
              Transactions Statistics</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=view-info&type=loan">
              View Loan Information</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=loan-application">
              Add Loan</span>
            </a>
          </li>       
          
          <li>
            <a href="index.php?page=my-loan">
              Individual Loan Details</span>
            </a>
          </li>
          <?php if($role == "Admin"){
            echo '<li>
            <a href="index.php?page=delete-loan">
              <font color="red">Delete Loan Details</font></span>
            </a>
          </li>';
          }?>
           <li>
            <a href="index.php?page=view-info&type=trash">
              Trash Can</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=import">
              Import</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=export">
              Export</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=edit-values">
              Edit Values</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=view-info&type=shares">
              View Shares Information</span>
            </a>
          </li>
          <?php if($role == "Admin"){
            echo '
          <li>
            <a href="index.php?page=add-share">
              Add Share(s)</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=remove-share">
              Remove Share(s)</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=transfer-share">
              Transfer Share(s)</span>
            </a>
          </li>';
        }
          ?>
          <li>
            <a href="index.php?page=view-info&type=cashflows">
              <span>View Cash Inflows and Outflows</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cashinflow">
              <span>Add Cash Inflow</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=cashoutflow">
              <span>Add Cash Outflow</span>
            </a>
          </li> 
          <li>
            <a href="index.php?page=view-info&type=bank">
              List of Banks</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=add-bank">
              Add Bank Account</span>
            </a>
          </li>
          <li>
            <a href="index.php?page=bank-deposit">
              Add Bank Deposit</span>
            </a>
          </li> 
          <li>
            <a href="index.php?page=bank-withdraw">
              Add Bank Withdraw</span>
            </a>
          </li> 
          <li>
            <a href="index.php?page=view-info&type=bank-transactions">
              View Bank Transactions</span>
            </a>
          </li>       
		</ul>
	</div>
</div>