<?php 
echo $msg->breadcrumb("User","Logout");
if(isset($_GET['page'])){
	$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Logged Out","N/A",$user,"0","0","Successful"));
	session_destroy();
	echo $msg->success("Logged out Successfuly");
	echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
} 
?>
