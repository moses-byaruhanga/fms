<?php echo $msg->breadcrumb("Members","Dissmiss Member"); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){
	//no data to load
}
else{
	if(!empty($_GET['account'])){
		$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
	}
	$account = $_SESSION['account'];
	//get names
	$names = $db->_get("member", $db->_toString(array("accountno"),array($account)),"surname")." ".$db->_get("member", $db->_toString(array("accountno"),array($account)),"other_name");	
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title warning">Are you sure that you want to dissmiss <?php echo $names." | ".$account; ?>?</h5>
		<?php echo $int->alert("danger", "This action can not be undone; If you are sure, provide your password");?>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="password" class="form-control" id="floatingPass" placeholder="Enter Your Password" name="user_pass">
					<label for="floatingPass">Enter Your Password To Confirm</label>
				</div>
			</div>
			<div class="col-md-6">
				<button type="submit" class="btn btn-danger btn-lg" name="dissmiss-member"><i class='bi bi-trash'></i> Dissmiss</button>
				<a href="index.php?page=dashboard" class="btn btn-success btn-lg">Cancel & Go Home</a>
			</div>
		</form>
	</div>
</div>
<?php } ?>


