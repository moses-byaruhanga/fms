<?php 
echo $msg->breadcrumb("Members","Monthly Payments",$help->monthly_payments());
//get date from db
$amount = $db->_get("settings",$db->_toString(array("field"),array("monthlyPayment")),"value");
if($amount == "null"){
	$amount = 1000;
}
$today = $db->getDate();
$todyString = $db->getFormatDate($today,0);
$condition = "amount = '".$amount."' ORDER BY `id` DESC LIMIT 1";
$lastDate = $db->_get("monthlypayments",$condition,"date");
$lastDate = $db->getFormatDate($lastDate,0);
$todayDateOfMonth = date("d",strtotime($todyString));
if($lastDate == $todyString || $todayDateOfMonth != "01"){
	echo $int->alert("info","The time is not due for effecting the monthly");
}
else{
	echo $int->add_button_monthly_payment("Effect Monthly Payments");
	echo $int->alert("warning","This transaction may take arround 5 minutes, the time depends on the number of accounts");
}
$jsonData = $db->get_data("monthlypayments", array("date", "accountno", "amount"));
if($jsonData == "null"){
	echo $int->alert("info", "Sorry; there are no monthly payments yet!");		
}
else
{	
	$table_header = "List of monthly payments";
	$head_row = array("#","date", "accountno", "amount");
	$data = json_decode($jsonData, true);
	$i = 0;
	foreach ($data as $item) {
		$no = $i+1;
		$individual_row[$i++] = array($no++,$item['date'],$item['accountno'],$item['amount']);
	}
	for($i=0;$i<count($data);$i++){
		$table_body[$i] = $individual_row[$i];
	}		
	$table = $int->_table($table_header,$head_row,$table_body);
	echo $table;
}

?>
