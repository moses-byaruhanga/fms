<?php 
if(empty($_GET['type'])){
	$info_type = "members";
}
else{
	$info_type = $_GET['type'];
}


echo $msg->breadcrumb(ucfirst($info_type), str_replace("-", " ", $info_type), $help->view_info($info_type));
if($info_type == "transactions"){
	echo $int->load_account_number("load_account");
	if($surname == "Surname"){

	}
	else{
	$tbhd = $surname." ".$othernames."'s Transactions / Bal: Shs"." ".$bal;
	$cond = "`accountno` = '".$_SESSION['account']."' ORDER BY `s/n` DESC";
	$jsonData = $db->get_data("hist", array("paydate", "amount", "acumulatedamount", "receiptno", "type", "accountno", "charge"), $cond);
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no transactions yet!");		
	}else{
		$data = json_decode($jsonData, true);
		$head_row = array("#","paydate", "amount", "acumulatedamount", "receiptno", "type", "accountno", "charge");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$individual_row[$i++] = array($no++,$item['paydate'],$item['amount'],$item['acumulatedamount'],$item['receiptno'],$item['type'],$item['accountno'],$item['charge']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($tbhd,$head_row,$table_body);
		echo $table;
	}
}

}
else if($info_type == "members"){
	$jsonData = $db->get_data("member", array("surname", "other_name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registrationfee", "accountno"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no members yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "List of Members ".$int->add_button("index.php?page=add-member","Add Member");
		$head_row = array("#","Name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registrationfee", "accountno","action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$individual_row[$i++] = array($no++,$item['surname']." ".$item['other_name'],$item['address'],$item['birthdate'],$item['ocupation'],$item['personalnin'],$item['contact'], $item['gender'],$item['registrationfee'],$item['accountno'], $int->button_group($item['accountno'],"index.php?page=edit-details&account","index.php?page=dissmiss-member&account"));
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}
}
else if($info_type == "ministatement"){
	echo $int->load_account_number("individual_transactions");
	echo $int->_table(
		"Viewing 10/120 Transactions  <a href='#'>View All</a>",
		array("S/N","NAME"), 
		array(array("1","me"),array("2","him")) 
	);
}
else if($info_type == "system-users"){	
	$jsonData = $db->get_data("systemusers", array("ID", "fullname", "username", "role", "userFloat", "status", "succTransactions", "failedTransactions"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no system users registered 
			<hr />
			Click <a href=index.php?page=add-user>here</a> to add one");
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "List of Users ".$int->add_button("index.php?page=add-user","Add Users");
		$head_row = array("#","fullname", "username", "role", "userFloat", "status", "succTransactions", "failedTransactions", "action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$action = "N/A";
			if($role == "Admin"){
				$action = $int->button_group($item['ID'],"index.php?page=user-profile&user_id","index.php?page=delete-user&id","index.php?page=cash-in&id");
			}
			if($item['fullname'] == "Byaruhanga Moses"){
				continue;
			}
			$individual_row[$i++] = array($no++,$item['fullname'],$item['username'],$item['role'],$item['userFloat'],$item['status'],$item['succTransactions'],$item['failedTransactions'],$action);
		}
		for($i=0;$i<count($data)-1;$i++){			
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;
	}
	
}
else if($info_type == "all-transactions"){
	if($db->isAllowed($role)){
		$cond = "";
	}
	else{
		$cond = "user ='".$user."'";
	}
	$jsonData = $db->get_data("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),$cond,"ID");
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no transactions yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		if($db->isAllowed($role)){
			$clearBtn = $int->popup_button("verticalycentered", "bi bi-trash", "danger"," Clear All Logs");
		}
		else
		{
			$clearBtn = "";
		}
		
		$table_header = "All System Logs".$clearBtn;
		$head_row = array("#","user","trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$individual_row[$i++] = array($no++,$item['user'],$item['trans_date'],$item['trans_type'],$item['accountno'],$item['accountname'],$item['trans_amount'],$item['charge'],$item['trans_status']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}


}
else if($info_type == "all-userstrace"){
	if($db->isAllowed($role)){
		$cond = "";
	}
	else{
		$cond = "user ='".$user."'";
	}	
	if($_GET['filter'] == "Today"){
		if($cond == ""){
		 	$cond = "datetime >= CURDATE()";
	    }
	    else{
	    	$cond = $cond." AND datetime >= CURDATE()";
	    }
	}
	
	$jsonData = $db->get_data("userstrace", array("ID", "datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),$cond);
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no transactions yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		$table_header = "Transactions";
		$head_row = array("#","datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$individual_row[$i++] = array($no++,$item['datetime'],$item['accountno'],$item['user'],$item['accountname'],$item['amount'],$item['charge'],$item['type'],$item['status'],$item['receiptno']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}
}
else if($info_type == "loan"){
	$cond = "ORDER BY `s/n` DESC";	
	$jsonData = $db->get_data("loan", array("accountno", "loanamount", "loandate", "repaymentdate", "intrestrate", "intrest", "repaymentamount", "receiptno","loanstatus", "fine", "times", "finerate", "loanFees"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no loan info yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		if($db->isAllowed($role)){
			$clearBtn = $int->add_button("index.php?page=loan-application","New Loan");
		}
		else
		{
			$clearBtn = "";
		}
		
		$table_header = "Loan Info".$clearBtn;
		$head_row = array("#","accountno","accountname", "loanamount", "loandate", "repaymentdate", "intrestrate", "intrest", "repaymentamount", "receiptno","loanstatus", "fine", "times", "finerate", "loanFees","Action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$action_btn = $int->button_group($item['accountno'],"index.php?page=my-loan&account","index.php?page=delete-loan&account");
			$name = $db->_get("member",$db->_toString(array("accountno"),array($item['accountno'])),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($item['accountno'])),"other_name");
			$individual_row[$i++] = array($no++,$item['accountno'],$name,$item['loanamount'],$item['loandate'],$item['repaymentdate'],$item['intrestrate'],$item['intrest'],$item['repaymentamount'],$item['receiptno'],$item['loanstatus'],$item['fine'],$item['times'],$item['finerate'],$item['loanFees'],$action_btn);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}
}
else if($info_type == "trash"){
	$jsonData = $db->get_data("deleted", array("surname", "other_name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registratonfee", "accountno"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no members yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "List of Deleted Members";
		$head_row = array("#","Name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registrationfee", "accountno","Action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;	
			if($role == "Admin"){
				$del = "<a class='btn btn-danger' href='index.php?page=delete-member&account=".$item['accountno']."'><i class='bi bi-trash'></i></a>";
			}		
			else{
				$del = "N/A";
			}
			$individual_row[$i++] = array($no++,$item['surname']." ".$item['other_name'],$item['address'],$item['birthdate'],$item['ocupation'],$item['personalnin'],$item['contact'], $item['gender'],$item['registratonfee'],$item['accountno'],$del);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}
}
else if($info_type == "shares"){
	$jsonData = $db->get_data("share", array("accountno", "shares", "amount"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no members yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "Shares Information";
		$head_row = array("#","accountno", "account_name", "shares", "amount","Action");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$action = "";
			if($role == "Admin"){
				$action = "<a class='btn btn-success' href='index.php?page=add-share&account=".$int->base64_url_encode($item['accountno'])."' title='Add Shares'><i class='bi bi-plus-circle'></i></a>&nbsp<a class='btn btn-warning' href='index.php?page=transfer-share&account=".$int->base64_url_encode($item['accountno'])."' title='Transfer Shares'><i class='bi bi-reply-all'></i></a>&nbsp;<a class='btn btn-danger' href='index.php?page=remove-share&account=".$int->base64_url_encode($item['accountno'])."' title='Remove Shares'><i class='bi bi-dash-circle'></i></a>";
			}
			$name = $db->_get("member",$db->_toString(array("accountno"),array($item['accountno'])),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($item['accountno'])),"other_name");
			$individual_row[$i++] = array($no++,$item['accountno'],$name,$item['shares'],$item['amount'],$action);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		echo $table;

	}
}
//Cash Flows
else if($info_type == "cashflows"){
	$jsonData = $db->get_data("finance", array("date", "type", "description", "amount", "user"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no cash inflows yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "Cashflows Information".$int->add_button("index.php?page=cashinflow","Add Cashinflow");
		$head_row = array("#","date", "type", "description", "amount", "user");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$type = "success";
			if($item['type'] == "cashoutflow"){
				$type = "danger";
			}
			$type = '<span class="badge bg-'.$type.'">'.$item['type'].'</span>';			
			$individual_row[$i++] = array($no++,$item['date'],$type,$item['description'],$item['amount'],$item['user']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		$cashinflows = $db->_add("finance","amount",$db->_toString(array("type"),array("cashinflow")));
		$cashoutflows = $db->_add("finance","amount",$db->_toString(array("type"),array("cashoutflow")));
		$stats_data = "".$cashinflows.",".$cashoutflows."";
		$lables = "'Cashinflows', 'Cashoutflows'";
		echo '<div class="row">
		<div class="col-md-8">
		';
		echo $table;
		echo '</div>
		<div class="col-md-4">
		<div class="card">
		<div class="card-body">	
		<h5 class="card-title">Totals and Graph</h5><br />
         <span style="color:green;">Total Cashinflows: <b>Shs '.$cashinflows.'</b></span>
         <hr />
         <span style="color:red;">Total Cashoutflows: <b>Shs '.$cashoutflows.'</b></span>
		<hr />
		<div id="pieChart"></div>
              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new ApexCharts(document.querySelector("#pieChart"), {
                    series: ['.$stats_data.'],
                    chart: {
                      height: 350,
                      type: "pie",
                      toolbar: {
                        show: true
                      }
                    },
                    labels: ['.$lables.']
                  }).render();
                });
              </script>
		</div></div></div></div>';
	}

}
else if($info_type == "bank"){
	$jsonData = $db->get_data("bank", array("name", "accountno", "date", "branch", "logo", "balance"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no registered banks yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		echo '<div class="row">';
		foreach ($data as $item) {
			echo $int->banck_card($item['accountno'], $item['logo'], $item['branch'], $item['balance']);
		}
		echo "</div>";
		

	}

}
else if($info_type == "bank-transactions"){
	$jsonData = $db->get_data("bank_transactions", array("date", "type", "amount", "accountno", "trans_branch", "trans_date","balance"));
	if($jsonData == "null"){
		echo $int->alert("info", "Sorry; there are no bank transactions yet!");		
	}
	else
	{
		$data = json_decode($jsonData, true);
		
		$table_header = "Bank Transactions";
		$head_row = array("#","date", "type", "amount", "accountno", "trans_branch", "trans_date","balance");
		$i = 0;
		foreach ($data as $item) {
			$no = $i+1;
			$type = "success";
			if($item['type'] == "Withdraw"){
				$type = "danger";
			}
			$type = '<span class="badge bg-'.$type.'">'.$item['type'].'</span>';			
			$individual_row[$i++] = array($no++,$item['date'],$type,$item['amount'],$item['accountno'],$item['trans_branch'],$item['trans_date'],$item['balance']);
		}
		for($i=0;$i<count($data);$i++){
			$table_body[$i] = $individual_row[$i];
		}		
		$table = $int->_table($table_header,$head_row,$table_body);
		$deposits = $db->_add("bank_transactions","amount",$db->_toString(array("type"),array("Deposit")));
		$withdraw = $db->_add("bank_transactions","amount",$db->_toString(array("type"),array("Withdraw")));
		$stats_data = "".$deposits.",".$withdraw."";
		$lables = "'Deposits', 'Withdraws'";
		echo '<div class="row">
		<div class="col-md-8">
		';
		echo $table;
		echo '</div>
		<div class="col-md-4">
		<div class="card">
		<div class="card-body">	
		<h5 class="card-title">Totals and Graph</h5><br />
         <span style="color:green;">Total Deposits: <b>Shs '.$deposits.'</b></span>
         <hr />
         <span style="color:red;">Total Withdraws: <b>Shs '.$withdraw.'</b></span>
		<hr />
		<div id="pieChart"></div>
              <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new ApexCharts(document.querySelector("#pieChart"), {
                    series: ['.$stats_data.'],
                    chart: {
                      height: 350,
                      type: "pie",
                      toolbar: {
                        show: true
                      }
                    },
                    labels: ['.$lables.']
                  }).render();
                });
              </script>
		</div></div></div></div>';
	}
}
else
{
	//more view 
}

//<!--Modals-->

//<!--Clear System Logs -->
echo $int->modal("Delete System Logs",$int->notice("danger","Warning","Are sure you want to delete all system logs?","This action can not be undone!"),"clear_logs","danger","bi bi-trash"," Clear All Logs");
?>




