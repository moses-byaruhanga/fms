<?php echo $msg->breadcrumb("Loan","Delete Loan"); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){
	unset($_SESSION['account']);
	//show nonthing here
}
else if(!empty($_GET['account'])){
	$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
}
if(empty($_SESSION['account'])){
	//show nothing
}
else 
{
	$accountno = $_SESSION['account'];
	$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
	$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
	if($loanBal == "null"){
		$loanBal = 0;
	}

	if($loanBal <= 0){
		$msg->failed("This member has no any running loan");
		echo $int->notice("danger",$surname." ".$othernames, "This member has no loan", "<a href='index.php?page=my-loan&account=".$accountno."'>View Loan Repayment Transactions</a>");
	}
	else{
		$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
		$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
		if($bal == "null"){
			$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
		}
	//get fine
		$fine = $db->get_loan_fine($accountno);
		$total_amount = $loanBal + $fine;
		if($fine > 0){
			$fine_d = '<h6><font color="red">This member has a fine of <b>Shs: '.$fine.' </b></font></h6>';
			$total_amount_d = '<h6><font color="red">The total amount due is <b>Shs: '.$total_amount.' </b></font></h6>';
		}
		else{
			$fine_d = '';
			$total_amount_d = '';
		}

		?>


		<!--Print Form for found member -->
		<div class="card">
			<div class="card-body">
				<h5 class="card-title"><?php echo $surname; ?> <?php echo $othernames; ?> | <?php echo $accountno; ?> | <font color="green">Bal: Shs <?php echo $bal; ?></font> | <font color="red">LoanBal: Shs <?php echo $loanBal; ?></font></h5><?php echo $fine_d; ?><?php echo $total_amount_d; ?>

				<?php echo $int->alert("danger", "This action can not be undone; All the loan information for this member will be deleted!. If you are sure, provide your password");?>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-6">
				<div class="form-floating">
					<input type="password" class="form-control" id="floatingPass" placeholder="Enter Your Password" name="user_pass">
					<label for="floatingPass">Enter Your Password To Confirm</label>
				</div>
			</div>
			<div class="col-md-6">
				<button type="submit" class="btn btn-danger btn-lg" name="delete-load-details"><i class='bi bi-trash'></i> Delete Loan Details</button>
				<a href="index.php?page=dashboard" class="btn btn-success btn-lg">Cancel & Go Home</a>
			</div>
		</form>
			</div>
		</div>
		<?php 
	} 
}

?>