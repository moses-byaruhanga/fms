<?php echo $msg->breadcrumb("Cashflows","Add Cashoutflows"); 
?>
<div class="card">
	<div class="card-body">
		<h5 class="card-title">Add Cashoutflow</h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->
			<div class="col-md-12">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingAmount" placeholder="Amount" name="amount" required>
					<label for="floatingAmount">Amount (Shs)</label>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-floating">
					<textarea name="description" class="form-control" style="min-height:100px;height: wrap-content;"></textarea>
					<label for="floatingDescription">Describe this transaction</label>
				</div>		
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="add_cash_outflow">Save</button>
				<a href="index.php?page=view-info&type=cashflows" class="btn btn-secondary btn-lg">Back</a>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>