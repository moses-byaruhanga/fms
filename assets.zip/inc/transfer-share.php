<?php echo $msg->breadcrumb("Shares","Transfer Share",$help->transfer_shares()); 
echo $int->load_account_number("load_account");
if($surname == "Surname" and empty(isset($_GET['account']))){

}else{
	if(!empty($_GET['account'])){
		$_SESSION['account'] = $int->base64_url_decode($_GET['account']);
	}
	$accountno = $_SESSION['account'];
	$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
	$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
	$shares =  $db->_get("share",$db->_toString(array("accountno"),array($accountno)),"amount");
	$num = $db->_get("share",$db->_toString(array("accountno"),array($accountno)),"shares");
	
?>


<!--Print Form for found member -->
<div class="card">
	<div class="card-body">
		<h5 class="card-title"><?php echo $surname; ?> <?php echo $othernames; ?> | <?php echo $accountno; ?> | <font color="green">Share Amount: Shs <?php echo $shares; ?></font> | <font color="red">Shares: <?php echo $num; ?></font></h5>

		<!-- Floating Labels Form -->
		<form class="row g-3" method="POST">
			<!--Member Name -->	
			<div class="col-md-6">
				<div class="form-floating">
					<input type="text" class="form-control" id="floatingAmount" placeholder="Amount" name="to_account" required>
					<label for="floatingAmount">To Account</label>
				</div>		
			</div>		
			<div class="col-md-6">
				<div class="form-floating">
					<input type="number" class="form-control" id="floatingAmount" placeholder="Amount" name="amount" required>
					<label for="floatingAmount">Share Amount (Shs)</label>
				</div>		
			</div>
			<div class="text-right">
				<button type="submit" class="btn btn-primary btn-lg" name="transfer-share">Transfer Shares</button>
				<button type="reset" class="btn btn-secondary btn-lg">Reset</button>
			</div>
			<!--EOF member account number -->		
		</form>
	</div>
</div>
<?php } ?>