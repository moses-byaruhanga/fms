<?php
require "cnf.php";
/**
 * Stores all the database functions
 */
class DataBase
{
	public $connect;
	public $data;
	public $sql;
	protected $server;
	protected $username;
	protected $password;
	protected $db;

	
	public function __construct()
	{
		$this->connect = null;
		$this->data = null;
		$this->sql = null;
		$dbc = new DataBaseConfig();
		$this->server = $dbc->server;
		$this->username = $dbc->username;
		$this->password = $dbc->password;
		$this->db = $dbc->db;
	}
	function dbConnect(){
		$this->connect = mysqli_connect($this->server, $this->username, $this->password, $this->db);
		return $this->connect;
	}
	function prepareData($data){
		return mysqli_real_escape_string($this->dbConnect(), stripslashes(htmlspecialchars($data)));
	}
	function login($username, $password){		
		$username = $this->prepareData($username);	
			$password = md5($password);
			$this->sql = "SELECT * FROM systemusers WHERE username = '$username' AND password = '$password'";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) == 1){
			$row = mysqli_fetch_assoc($result);
			$data = array($row["username"],$row["fullname"],$row["role"],$row["userFloat"],$row["status"],$row["succTransactions"],$row["failedTransactions"],$row["profile"]);
		}
		else
		{
			$data = array("null");
		}
		return $data;
	}
	//get date string
	function getDate(){
		return date('Y-m-d H:i:s');
	}
	function getDateNew(){
		return date('d/m/Y H:i:s');
	}
	function isAllowed($role){
		if($role == "Admin" || $role == "supperAdmin"){
			return true;
		}
		else
		{
			return false;
		}

	}
	function reportDate(){
		return date('d.m.Y');
	}	
	function getFormatDate($date, $q)
	{
		if($q == 0){
			$new_date = date("Y-m-d",strtotime($date));
		}
		else
		{
			$new_date = date("H:i:s",strtotime($date));
		}
		return $new_date;		
	}
	//get members details
	function member($acountno, $q){
		$data = $this->_get("member",$this->_toString(array("accountno"),array($acountno)),$q);
		return $data;
	}

	//get Saved System Managers
	function getUsersList(){
		$data = $this->get_data("systemusers", array("username"));
		if($data == "null"){
			return "";
		}
		else{
			$output = "";
			$data = json_decode($data, true);
			foreach ($data as $item){
				$output .= '<li><a class="dropdown-item" href="index.php?page=dashboard&transFilter='.$item['username'].'">'.$item['username'].'</a></li>';
			}
			return $output;
		}
	}
	function get_trans_brief($user){
		$cond = "user='".$user."' ORDER BY `ID` DESC LIMIT 2";
		$jsonData = $this->get_data("userstrace", array("ID", "datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),$cond);
		if($jsonData == "null"){
			$output = "";
		}
		else{
			$output = '<li>
            <hr class="dropdown-divider">
          </li>';
			$data = json_decode($jsonData, true);
			foreach ($data as $item){
				if($item['type'] == "Savings"){
					$class = "success";
				}elseif($item['type'] == "Withdraws"){
					$class = "danger";
				}
				else{
					$class = "worning";
				}
				$output .= '			
				<li class="notification-item">
            <i class="bi bi-box-arrow-right text-'.$class.'"></i>
            <div>
              <h4>'.$item['accountno'].'</h4>
              <p>A '.$item['type'].' of Shs '.$item['amount'].' made to '.$this->member($item['accountno'], "surname").' at '.$item['datetime'].' with charge of Shs '.$item['charge'].'.</p>
            </div>
          </li>
          	<li>
            <hr class="dropdown-divider">
          </li>';
			}
		}
		return $output;
	}

	//get recent activity
	function get_recent_activity($filter, $limit, $isToday, $user){
		//time filter
		if($isToday == 1){
			$date_filter = "trans_date >= CURDATE() AND";
		}
		else
		{
			$date_filter = "";
		}
		//limit
		if($limit == 0){
			$limit = "";
		}
		else{
			$limit = "LIMIT ".$limit;
		}
		//user filter($table,$condition, $query)
		$role = $this->_get("systemusers",$this->_toString(array("username"),array($user)),"role");
		if($this->isAllowed($role)){
			$user = "";
		}
		else{
			$user = "AND user ='".$user."'";
		}
		//content filter

		if($filter == "all" AND $date_filter == ""){
			if($user == ""){
			   $condition = "";
			}else{
				$condition = "user ='".$user."'";
			}
		}
		elseif($filter == "all" AND $date_filter != ""){
			$condition = "trans_date >= CURDATE() ".$user." ORDER BY `ID` DESC ".$limit;
		}
		elseif($filter == "Other"){
			$condition = $date_filter." trans_type != 'Savings' AND trans_type != 'Withdraws' AND trans_type != 'Loan Payment' AND trans_type != 'Logged In' ".$user."  ORDER BY `ID` DESC ".$limit;
		}
		else
		{
			$condition = $date_filter." trans_type = '".$filter."' ".$user."  ORDER BY `ID` DESC ".$limit;
		}
		$jsonData = $this->get_data("transactions", array( "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"), $condition);
		if($jsonData == "null"){
			$output = '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                Sorry, No records found
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
			$totalItems = 0;
		}else
		{
			$data = json_decode($jsonData, true);
			$totalItems = count($data);
			$output = "";			
			foreach ($data as $item){
				$tran_status = $item['trans_status'];
				if($tran_status == "Failed"){
					$tran_status = "<span class='badge bg-danger'>".$tran_status."</span>";
				}
				else
				{
					$tran_status = "<span class='badge bg-success'>".$tran_status."</span>";
				}
				if($item['trans_type'] == "Withdraws"){
					$class = "warning";
				}
				else
				{
					$class = "success";
				}
				if($item['trans_type'] == "Withdraws" || $item['trans_type'] == "Loan Payment" || $item['trans_type'] == "Savings"){
					$d_item = ''.$item['trans_type'].' made on '.$item['accountno'].' ('.$item['accountname'].') of <b>Shs '.$item['trans_amount'].'</b> with charges of <b>Shs '.$item['charge'].'</b> ('.$tran_status.')';
				}
				elseif($item['trans_status'] == "Failed"){
					$d_item = ''.$item['trans_type'].': '.$item['accountname'].' '.$tran_status.'';
					$class = "danger";
				}
				else
				{
					$d_item = ''.$item['trans_type'].': '.$item['accountname'].' '.$tran_status.'';
					$class = "info";
				}
				
				$output .= '<div class="activity-item d-flex">
							<div class="activite-label">'.$this->getFormatDate($item['trans_date'], 0).'<br />(<b>
							'.$this->getFormatDate($item['trans_date'], 1).'</b>)
							</div>
							<i class="bi bi-circle-fill activity-badge text-'.$class.' align-self-start"></i>
							<div class="activity-content">
								'.$d_item.' 
							</div>
						</div>';
			}
		}
		return $output;
	}
	//set system color
	function set_system_color($user, $color){
		$this->sql = "UPDATE account SET system_color = '$color' WHERE username = '$user'";
		mysqli_query($this->dbConnect(), $this->sql);
	}	
	function generate_user_number()
	{
		$permitted_chars1 = '0123456789';
		$prt1 = date('Y');
		$prt2 = date('d');
		$prt3 = substr(str_shuffle($permitted_chars1), 0, 4);
		return  "".$prt1."/".$prt2."/".$prt3."";
	}
	
	//check exists
	function _check($table, $fields, $values){
		$condition = "";
		for($i=0;$i<count($fields)-1;$i++){
			$condition = $condition."".$fields[$i]." = '".$values[$i]."' AND ";
		}
		$condition = $condition."".$fields[count($fields)-1]." = '".$values[count($fields)-1]."'";
		$this->sql = "SELECT * FROM $table WHERE $condition";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			return true;
		}
		else
		{
			return false;
		}
	}
	function _image_check($exe, $size){
	//check extention
		if($exe == 'png'
			|| $exe == 'jpg'
			|| $exe == 'jpeg'
			|| $exe == 'PNG'
			|| $exe == 'JPEG'
			|| $exe == 'JPG'
		)
		{
			if($size>=10000000)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		else
		{
			return false;
		}

	}
	//save function
	function _save($table, $fields, $values){
		$field_string = "";
		$value_string = "";
		//Create fields string
		for($i=0; $i < count($fields)-1; $i++){ 
			$field_string = $field_string." ".$fields[$i].",";
		}
		$field_string = $field_string." ".$fields[count($fields)-1];
		//Create value strings
		for($j=0; $j < count($values)-1; $j++){
			$value_string = $value_string." '".$values[$j]."',";
		}
		$value_string = $value_string." '".$values[count($values)-1]."'";
		
		$this->sql = "INSERT INTO $table($field_string) VALUES($value_string)";
		if(mysqli_query($this->dbConnect(), $this->sql)){
			return true;
		}
		else
		{
			return false;
		}
	}
	//update database
	function _update($table, $columns, $values, $where, $conditions){
		$sql_string = "";
		$where_condition = "";
		for($i=0;$i<count($columns)-1;$i++){
			$sql_string = $sql_string."".$columns[$i]." = '".$values[$i]."', ";
		}
		$sql_string = $sql_string."".$columns[count($columns)-1]." = '".$values[count($columns)-1]."'";

		for($j=0;$j<count($where)-1;$j++){
			$where_condition = $where_condition."".$where[$j]." = '".$conditions[$j]."' AND ";
		}
		$where_condition = $where_condition."".$where[count($where)-1]." = '".$conditions[count($where)-1]."'";

		$this->sql = "UPDATE $table SET $sql_string WHERE $where_condition";
		if(mysqli_query($this->dbConnect(), $this->sql)){
			return true;
		}
		else
		{
			return false;
		}	

	}	
	//Delete from database
	function _delete($table, $condition){		
		$this->sql = "DELETE FROM $table WHERE $condition";
		if(mysqli_query($this->dbConnect(),$this->sql)){
			return true;
		}
		else
		{
			return false;
		}
	}
	//Truncate table
	function _truncate($table){		
		$this->sql = "TRUNCATE `$table`";
		if(mysqli_query($this->dbConnect(),$this->sql)){
			return true;
		}
		else
		{
			return false;
		}
	}
	//Array to string
	function _toString($columns, $values){
		$where_condition = "";
		for($j=0;$j<count($columns)-1;$j++){
			$where_condition = $where_condition."".$columns[$j]." = '".$values[$j]."' AND ";
		}
		$where_condition = $where_condition."".$columns[count($columns)-1]." = '".$values[count($columns)-1]."'";
		return $where_condition;
	}
	//getData
	function _get($table,$condition, $query){
		$this->sql = "SELECT $query FROM $table WHERE $condition";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			$row = mysqli_fetch_assoc($result);
			return $row[$query];
		}
		else
		{
			return "null";
		}
	}
	
	//get total
	function _count($table, $condition = ""){
		if($condition == ""){
			$this->sql = "SELECT COUNT(*) AS total FROM $table";
		}
		else
		{
			$this->sql = "SELECT COUNT(*) AS total FROM $table WHERE $condition";
		}	

		$result = mysqli_query($this->dbConnect(), $this->sql);
		$row = mysqli_fetch_assoc($result);
		return $row['total'];
	}
	//cumulative addition
	function _add($table,$query,$condition = ""){
		if($condition == ""){
			$this->sql = "SELECT $query FROM $table";
		}
		else{
			$this->sql = "SELECT $query FROM $table WHERE $condition";
		}
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0)
		{
			$total = 0;
			while($row = mysqli_fetch_assoc($result)){
				$total = $total + $row[$query];
			}
			return $total;
		}
		else
		{
			return 0;
		}
	}
	//select input
	function _input_select($name,$table,$query,$value,$condition,$required="required", $more = "", $brackate_value=""){
		if($condition == ""){
			$this->sql = "SELECT * FROM $table";
		}
		else
		{
			$this->sql = "SELECT * FROM $table WHERE $condition";
		}
		$result = mysqli_query($this->dbConnect(), $this->sql);
		$select = '<div class="col-md-12">
				<div class="form-floating"><select id="floatingSelect" name="'.$name.'" class="form-select" id="select" '.$required.'>';		
		if(mysqli_num_rows($result) > 0){
			$select .= '<option value="" selected disabled>Choose option</option>
			';
			while ($row = mysqli_fetch_assoc($result)) {	
			     if($brackate_value == ""){
			     	$select .= '<option value="'.$row[$value].'">'.$row[$query].'</option>';

			     }else{
			     	$select .= '<option value="'.$row[$value].'">'.$row[$query].' ('.$row[$brackate_value].')</option>';
			     }			
								
				
			}
			$select .= $more;
		}

		else
		{
			$select .= '<option value="" disabled>No results found</option>';
		}
		$select .=  '</select><label for="floatingSelect">Select Option</label></div></div>';
		return $select;
	}
	function generate_account_number($m_type) //more research here
	{
		//Get the total members
		$total_registered_members = $this->_count('member');
		$new_num = $total_registered_members + 1;
		$new_num = str_pad($new_num, 4, '0', STR_PAD_LEFT);
		$part1  = $this->_get("settings",$this->_toString(array("field"),array("accountNumberPrefix")),"value");
		$rand = rand(100,999);
		if($part1 == "null"){
			$part1 = "MYSACCO";
		}
		$part2 = strtoupper($m_type[0]);
		$ac_no = $part1."/".$part2."/".$new_num."/".$rand;
		$similer_no = true;
		while($similer_no){
			if($this->_check("member",array("accountno"),array($ac_no))){
				$new_num = $new_num + 1;
				$new_num = str_pad($new_num, 4, '0', STR_PAD_LEFT);
				$rand = rand(100,999);
				$ac_no = $part1."/".$part2."/".$new_num."/".$rand;			
			}
			else{
				$similer_no = false;
			}
		}
		return  $ac_no;
	}
	function get_subjects($sch_no, $level){
		$this->sql = "SELECT * FROM subject WHERE school_number = '$sch_no' AND level = '$level'";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			$subjects = "";
			while($row = mysqli_fetch_assoc($result)){
				$subjects = $subjects."".$row['sub_id'];			
			}
			return $subjects;
		}
		else
		{
			return "null";
		}
	}
	
	function get_data($tb, $columns, $condition = "", $orderby = ""){
		if($orderby != ""){
			$orderby = "ORDER BY `$orderby` DESC"; 
		}
		if($condition == ""){
			$this->sql = "SELECT * FROM $tb $orderby";
		}
		else
		{
			$this->sql = "SELECT * FROM $tb WHERE $condition $orderby";
		}
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			$data = array();
			while($row = mysqli_fetch_assoc($result)) {
				$temp = array();
				for($i = 0; $i< count($columns); $i++){
					$result_column = $columns[$i];
					$temp[$columns[$i]] = $row[$result_column];
				}
				array_push($data, $temp);
			}
			return json_encode($data);
		}
		else
		{
			return 'null';
		}
	}
	
	function _input_select_editable($name,$table,$query,$value,$condition,$required="required", $update_val = ""){
		if($condition == ""){
			$this->sql = "SELECT $query, $value FROM $table";
		}
		else
		{
			$this->sql = "SELECT $query, $value FROM $table WHERE $condition";
		}
		if($update_val == ""){
			$placeholder = 'placeholder="Enter or select value"';
		}
		else
		{
			$placeholder = 'value="'.$update_val.'"';
		}
		$result = mysqli_query($this->dbConnect(), $this->sql);
		$select = '<input name="'.$name.'" class="form-control" type="text"  list="value" '.$placeholder.' '.$required.'/>
		<datalist id="value">';		
		if(mysqli_num_rows($result) > 0){
			while ($row = mysqli_fetch_assoc($result)) {
				$select .= '<option value="'.$row[$value].'">'.$row[$query].'</option>';
			}
		}
		else
		{
			$select .= '<option value="" disabled>No results found</option>';
		}
		$select .=  '</datalist>';
		return $select;
	}
	function getFrequentMembers(){
		
	}
	function update_repository($amount, $type, $charges = 0){
		$date = $this->getDate();
		if($type == 1){ //Addition
			//check if is the first
			$cond1 = "date >= CURDATE()";
			if($this->_count("repository",$cond1) >= 1){
				//today
				$mainbalance = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainbalance") + $amount;
				$mainwithdraws = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainwithdraws");
				$mainsavings = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainsavings") + $amount;
				$dailywithdraw = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailywithdraw");
				$dailysaving = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailysaving") + $amount;
				$maincharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"maincharges");
				$dailycharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailycharges");
			}
			else{
				//yesto 
				$mainbalance = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainbalance") + $amount;
				$mainwithdraws = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainwithdraws");
				$mainsavings = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainsavings") + $amount;
				$dailywithdraw = 0;
				$dailysaving = $amount;
				$maincharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"maincharges");
				$dailycharges = 0;
			}		

		}
		else{ //Minus
			if($this->_count("repository",$cond1) >= 1){
				//today
				$mainbalance = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainbalance") - $amount;
				$mainwithdraws = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainwithdraws") + $amount;
				$mainsavings = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainsavings");
				$dailywithdraw = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailywithdraw") + $amount;
				$dailysaving = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailysaving") + $amount;
				$maincharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"maincharges") + $charges;
				$dailycharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"dailycharges") + $charges;

			}
			else{
				//yesto
				$mainbalance = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainbalance") - $amount;
				$mainwithdraws = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainwithdraws") + $amount;
				$mainsavings = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"mainsavings");
				$dailywithdraw = $amount;
				$dailysaving = 0;
				$maincharges = $this->_get("repository",$this->_toString(array("`s/n`"),array("1")),"maincharges") + $charges;
				$dailycharges = $charges;
			}

		}
		//Update repository
		$this->_update("repository", 
			array("date", "mainbalance", "mainwithdraws", "mainsavings", "dailywithdraw", "dailysaving", "maincharges", "dailycharges"),
			array($date, $mainbalance, $mainwithdraws, $mainsavings, $dailywithdraw, $dailysaving, $maincharges, $dailycharges),
			array("`s/n`"),
			array("1"));

	}
	function update_user_float($user,$amount,$type){
		if($type == 1){ //Adding
			$float = $this->_get("systemusers",$this->_toString(array("username"),array($user)),"userFloat");
			$float = $float + $amount;
			$st = $this->_get("systemusers",$this->_toString(array("username"),array($user)),"succTransactions");
			$st = $st + 1;

		}
		else
		{
			$float = $this->_get("systemusers",$this->_toString(array("username"),array($user)),"userFloat");
			$float = $float - $amount;
			$st =  $this->_get("systemusers",$this->_toString(array("username"),array($user)),"succTransactions");
			$st = $st + 1;
		}
		//update the table
		$this->_update("systemusers", array("userFloat","succTransactions"),array($float,$st), array("username"), array($user));
	}
///////////////Loan/////////////////
	function get_loan_times($accountno){
		$this->sql = "SELECT * FROM loan WHERE accountno = '$accountno' ORDER BY `times` DESC LIMIT 1";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			$res = mysqli_fetch_assoc($result);
			return $res['times'];
		}
		else{
			return 0;
		}
		
	}

	///get loan repayment fine///
	function get_loan_fine($accountno){	
	$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";	
		$repay_date = $this->_get("loan",$loanCond,"repaymentdate");		
		if($repay_date == "null"){
			$repay_date = $this->getDateNew();
		}		
		$today = $this->getDateNew();
		$startDate = DateTime::createFromFormat('d/m/Y H:i:s', $repay_date);
		$endDate = DateTime::createFromFormat('d/m/Y H:i:s', $today);
		$interval = $startDate->diff($endDate);
		$days = $interval->days;				
		if($startDate >= $endDate){
			$days = 0;
		}
		//get the fine rate
		$fine_rate = $repay_date = $this->_get("loan",$loanCond,"finerate");
		if($fine_rate == "null"){
			$fine_rate = 10;
		}
		//echo "| ".$fine_rate;
		//get the loan balance
		$amount = $this->_get("loan",$loanCond,"repaymentamount");
		if($amount == "null"){
			$amount = 0;
		}

		//echo "| ".$amount;
		//get the fine of one day
		$fine = round(($fine_rate / 100) * $amount,0);
		//echo "| ".$fine;
		$fine = $fine * $days; //get fine total
		return $fine;
	}

	//Implement the loan repayment
	function repay_loan($account, $paid_amount, $balance, $loanstatus,$fine,$receipt){
		//get times number
		$loanCond = "`accountno` = '".$account."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$times = $this->_get("loan",$loanCond,"times");
		//save to loan
		$this->_update("loan",
	     array("repaymentamount","loanstatus","fine"),
	     array($balance,$loanstatus,$fine),
	     array("accountno","times"),
	     array($account,$times));
		//save to payment
		$this->_save("payment",
	    array("accountno", "paymentdate", "paidamount", "balance", "loanstatus", "receiptno", "times"),
	    array($account,$this->getDateNew(),$paid_amount,$balance,$loanstatus,$receipt,$times));
	    return true;
	}

	//Search database
	function search($tb,$q,$fileds){
		$sql_string = "";
		$where_condition = "";
		for($i=0;$i<count($fileds)-1;$i++){
			$sql_string = $sql_string."".$fileds[$i]." LIKE '%".$q."%' OR ";
		}
		$sql_string = $sql_string."".$fileds[count($fileds)-1]." LIKE '%".$q."%'";
		$this->sql = "SELECT * FROM $tb WHERE $sql_string";
		$result = mysqli_query($this->dbConnect(), $this->sql);
		if(mysqli_num_rows($result) > 0){
			$data = array();
			while($row = mysqli_fetch_assoc($result)) {
				$temp = array();
				for($i = 0; $i< count($fileds); $i++){
					$result_column = $fileds[$i];
					$temp[$fileds[$i]] = $row[$result_column];
				}
				array_push($data, $temp);
			}
			return json_encode($data);
		}
		else
		{
			return 'null';
		}
	}

	function isConneted(){
		switch (connection_status())
		{
		case CONNECTION_NORMAL:
		  $msg = true;
		  break;
		case CONNECTION_ABORTED:
		  $msg = false;
		  break;
		case CONNECTION_TIMEOUT:
		  $msg = false;
		  break;
		case (CONNECTION_ABORTED & CONNECTION_TIMEOUT):
		  $msg = false;
		  break;
		default:
		  $msg = false;
		  break;
		}
		return $msg;
	}

	///Send Messages//
	function send_message($accountno, $msg){
		//get the contact
		$contact = $this->_get("member",$this->_toString(array("accountno"),array($accountno)),"contact");
		if($contact[0] == "0"){
			$contact = ltrim($contact, $contact[0]);
			$contact = "256".$contact;
		}
		else if($contact[0] == "+"){
			$contact = ltrim($contact, $contact[0]);	
		}	
		//get the account name
		$name = $this->_get("member",$this->_toString(array("accountno"),array($accountno)),"surname");
		$name = ucfirst($name);
		$msg = "Dear ".$name.", ".$msg;
		//format the message
		$msg = str_replace(' ', '+', $msg);
		//check internet connection
		//initialze the message
		$ch = curl_init();
		$url = 'https://www.egosms.co/api/v1/plain/?number=%2B'.$contact.'&message=%20'.$msg.'&%20username=moses123&%20password=Moses123@155&sender=FMS';
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_exec($ch);
		curl_close($ch);
	}
	function monthly_payments(){
		//get all accounts
		$accounts = $this->get_data("member", array("accountno"));
		$accounts = json_decode($accounts, true);
		//get monthly pay
		$amount = $this->_get("settings",$this->_toString(array("field"),array("monthlyPayment")),"value");
		if($amount == "null"){
			$amount = 1000;
		}
		foreach($accounts as $account){
			$accountno = $account['accountno'];
			//get_account balance
			$bal = $this->_get("currentt",$this->_toString(array("accountno"),array($accountno)),"acumulatedamount");
			if($bal == "null"){
				$bal = $this->_get("account",$this->_toString(array("accountno"),array($accountno)),"deposit");
			}
			$rm_balance = $bal - $amount;
			if($rm_balance >= 0){
				//update currentt
				$this->_update("currentt",array("paydate","amount","acumulatedamount","receiptno","type","charge"), array($this->getDate(),$amount, $rm_balance, "N/A", "W", "0"), array("accountno"), array($accountno));
				//update the deposit
				$this->_update("account",array("deposit"), array($rm_balance), array("accountno"), array($accountno));
				//Save this to payment table
				$this->_save("monthlypayments",array("date", "accountno", "amount"),array($this->getDate(),$accountno,$amount));
			}
		}

	}
}

?>