<?php
class DataBaseConfig
{
	public $server;
	public $username;
	public $password;
	public $db;
	
	public function __construct($database = "")
	{
		$this->server = "localhost";
		$this->username = "root";
		$this->password = "";
		$this->db = "fmg_db";
	}

}



?>