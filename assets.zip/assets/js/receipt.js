now = new Date();
randomNum = '';
randomNum += Math.round(Math.random() * 9);
randomNum += Math.round(Math.random() * 9);
randomNum += now.getTime().toString().slice(-5);
window.onload = function() {
  document.getElementById("receipt_no").value = randomNum;
}