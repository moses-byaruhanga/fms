<?php 
###########File for listeners##############
//New organisation register 
if(isset($_POST['save-btn'])){
	$pass = $_POST['Admin_Password'];
	$c_pass = $_POST['c_Admin_Password'];
	if($pass != $c_pass){
		echo $msg->failed("Passwords Do Not Match");
	}
	else
	{
		$org_name = $_POST['org_name'];
		$basic_color = $_POST['basic_color'];
		$user = $_POST['admin_username'];
		$role = "Admin";
		if($db->_save("basic_info", array("organisation_name","logo","basic_color"),array($org_name,"",$basic_color))){
			$db->_truncate("login");
			$pass = md5($pass);
			$db->_save("login",array("username","password"),array($user,$pass));
			$db->_save("systemusers",array("fullname", "username", "password", "role", "userFloat", "status", "succTransactions", "failedTransactions"),array($org_name,$user,$pass,"Admin","0","open","0","0"));
			echo $msg->success("Success; Redirecting to Login...");
			echo "<meta http-equiv='refresh' content='2; url=index.php'>";
		}
	}
}
//Login listener
if(isset($_POST['login-btn'])){
	$user = $_POST['username'];
	$pass = $_POST['password'];
	$login = $db->login($user,$pass);
	if($login[0] == "null"){
		//Save to transactions
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Logged In","N/A",$user,"0","0","Failed"));
		echo $msg->failed("Invalid Login Details; Please contact administrator for help");

	}else
	{
		session_start();
		$_SESSION['user'] = $login[0];
		$_SESSION['role'] = $login[2];
		$_SESSION['name'] = $login[1];
		$_SESSION['float'] = $login[3];
		$_SESSION['status'] = $login[4];
		$_SESSION['st'] = $login[5];
		$_SESSION['ft'] = $login[6];
		$_SESSION['profile'] = $login[7];		
		echo $msg->success("Login Success; Redirecting to Dashboard...");
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Logged In","N/A",$user,"0","0","Successful"));
		//Go to dashboard
		echo "<meta http-equiv='refresh' content='2; url=home/index.php?page=dashboard'>";
	}
	
}
//Find member
if(isset($_POST['find-member'])){
	if($db->_check("member", array("accountno"), array($_POST['accountno']))){
		$_SESSION['accountno'] = $_POST['accountno'];
		echo $msg->success("accountno Exist");
	}
	else{
		unset($_SESSION['accountno']);
		echo $msg->failed("No account number");
	}
}
//Profile image
if(isset($_POST['reset_profile'])){

	$pic_name = pathinfo($_FILES['profile']['name']);
	$id = $_SESSION['user_id'];
	$ext = $pic_name['extension'];
	$size = $_FILES['profile']['size'];
	if($db->_image_check($ext, $size)){
		$image = $_FILES['profile']['name'];
		if($db->_update("systemusers", array("profile"), array($image), array("ID"), array($id))){
			move_uploaded_file($_FILES['profile']['tmp_name'],"../assets/img/profile/".basename($_FILES['profile']['name']));
			$_SESSION['profile'] = $image;
			$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Profile Picture","N/A",$user,"0","0","Successful"));
			$msg->success("Profile Picture Updated Successfuly!");
		}
	}
	else
	{
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Profile Picture","N/A",$user,"0","0","Failed"));
		$msg->failed("The image is too large or file format is unsupported");
	}
}
//delete image
if(isset($_POST['delete_profile'])){
	$id = $_SESSION['user_id'];
	$image = "default.png";
	if($db->_update("systemusers", array("profile"), array($image), array("ID"), array($id))){			
		$_SESSION['profile'] = $image;
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Profile Picture","N/A",$user,"0","0","Successful"));
		$msg->success("Profile Picture Deleted Successfuly!");
	}
}
//Change profile
if(isset($_POST['save-edit-profile'])){
	$id = $_SESSION['user_id'];
	$name = $_POST['name'];
	if($db->_update("systemusers", array("fullname"), array($name), array("ID"), array($id))){			
		$_SESSION['name'] = $name;
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Full Name","N/A",$user,"0","0","Successful"));
		$msg->success("Saved Successfuly!");
	}
}
//Save changes 
if(isset($_POST['save-change-password'])){
	$password = $_POST['password'];
	$password = md5($password);
	$id = $_SESSION['user_id'];
	if($db->_check("systemusers",array("password"),array($password))){
		$newPassword = $_POST['newpassword'];
		$cnewPassword = $_POST['renewpassword'];
		if($newPassword != $cnewPassword){
			$msg->failed("Passwords do not match");
		}
		else{
			if($db->_update("systemusers", array("password"), array(md5($newPassword)), array("ID"), array($id))){	
				$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Password","N/A",$user,"0","0","Successful"));	
				$msg->success("Password Changed Successfuly!");
			}
			else{
				$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Password Change","N/A",$user,"0","0","Failed"));
				$msg->failed("Error; Please try again");
			}
		}
		
	}
	else{
		$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Changed Profile Picture","N/A",$user,"0","0","Failed"));
		$msg->failed("User password is incorrect");
	}
}

//Save changes admin change password
if(isset($_POST['save-admin-change-password'])){
	$password = $_POST['password'];
	$password = md5($password);
	$id = $_SESSION['user_id'];
	$newPassword = $_POST['newpassword'];
	$cnewPassword = $_POST['renewpassword'];
	if($newPassword != $cnewPassword){
		$msg->failed("Passwords do not match");
	}
	else{
		if($db->_update("systemusers", array("password"), array(md5($newPassword)), array("ID"), array($id))){
			$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Admin Change Password","N/A",$user,"0","0","Successful"));		
			$msg->success("Password Changed Successfuly!");
		}
		else{
			$db->_save("transactions", array("user","trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,"Admin Changed Password","N/A",$user,"0","0","Failed"));
			$msg->failed("Error; Please try again");
		}
	}
}

//Clear all logs
if(isset($_POST['clear_logs'])){
	if($db->_truncate("transactions")){
		$msg->success("System Logs Cleared Successfuly");
	}
	else{
		$msg->failed("Error; Please try again");
	}
}
if(isset($_POST['add-member'])){
	//Get Inputs
	$inputs = array(
		$_POST['surname'],
		$_POST['other_name'],
		$_POST['address'],
		$_POST['occupation'],
		$_POST['type'],
		$_POST['gender'],
		$_POST['dob'],
		$_POST['nin'],
		$_POST['fees'],
		$_POST['contact'],
		$_POST['s1name'],
		$_POST['S1contact'],
		$_POST['S1nin'],
		$_POST['S2name'],
		$_POST['S2contact'],
		$_POST['S2nin'],
		$db->generate_account_number($_POST['type']),
		$_POST['deposit']
	);
	//Save to member tabel
	if($db->_check("member",array("accountno"),array($inputs[16]))){
		$msg->failed("Account Nummber Duplicate");
	}
	else
	{
		if($db->_save("member",
			array("surname", "other_name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registrationfee", "accountno"),
			array($inputs[0],$inputs[1],$inputs[2],$inputs[6],$inputs[3],$inputs[7],$inputs[9],$inputs[5],$inputs[8],$inputs[16]))){
			//Save to acount			
			$db->_save("account", 
				array("personalid", "deposit", "dateopened", "seconder1", "seconder1contact", "seconder1nin", "seconder2", "seconder2contact", "seconder2nin", "accountno"),
				array($inputs[7],$inputs[17],$db->getDate(),$inputs[10],$inputs[11],$inputs[12],$inputs[13],$inputs[14],$inputs[15],$inputs[16]));
		//Save to sahres
		$shares = round($inputs[8]/10000, 2);
		$db->_save("share", 
			array("accountno", "shares", "amount"),
			array($inputs[16],$shares,$inputs[8]));

		//Save to share hist
		$db->_save("share_hist", 
			array("date", "type", "shares", "accountno"),
			array($db->getDate(),"B",$shares,$inputs[16]));
		$db->update_repository($inputs[17],1);

		//Save to logs
		$db->_save("transactions", 
			array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
			array($user,$db->getDate(),"Member Registration",$inputs[16],$inputs[0]." ".$inputs[1],$inputs[17],"0","successful"));

		 $message = "Cash Deposit of UGX ".$amount." on A/C: ".$inputs[17]." was successfull. Balance: UGX ".$bal;
	     $db->send_message($inputs[16],$message);

		$msg->success("Member Added Successfuly");
	}
	else
	{
			//Save to logs
		$db->_save("transactions", 
			array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
			array($user,$db->getDate(),"Member Registration",$inputs[16],$inputs[0]." ".$inputs[1],$inputs[17],"0","Failed"));
		$msg->failed("Error; Please try again");
	}
}
}

//get member details/load account details
if(isset($_POST['load_account'])){
	unset($_GET['account']);
	$accountno = $_POST['accountno'];	
	if($db->_check("member",array("accountno"), array($accountno))){
	$_SESSION["account"] = $accountno;	
		$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
		$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
		if($bal == "null"){
			$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
		}
		$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
		if($loanBal == "null"){
			$loanBal = 0;
		}
	}
	else
	{
		//use the four digits
		$condition = "accountno LIKE '%".$accountno."'";
		$accountno = $db->_get("member",$condition,"accountno");
		if($accountno == "null"){
			$msg->failed("Account Number does not exist!");
		}
		else{
			$_SESSION["account"] = $accountno;
			$surname = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
		$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
		$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
		if($bal == "null"){
			$bal = $db->_get("account",$db->_toString(array("accountno"),array($accountno)),"deposit");
		}
		$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
		if($loanBal == "null"){
			$loanBal = 0;
		}
		}
		
	}
}

///======Deposit==========//
if(isset($_POST['deposit'])){
	$receipt = $_POST['receiptno'];
	$amount = $_POST['amount'];
	$account = $_SESSION["account"];
	//get last bal
	$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($account)),"acumulatedamount");
	if($bal == "null"){
		$bal = $db->_get("account",$db->_toString(array("accountno"),array($account)),"deposit");
	}
	$acc_amount = $bal + $amount;
	//update account balance
	if($db->_check("currentt",array("accountno"), array($account))){
		$db->_update("currentt",array("paydate","amount","acumulatedamount","receiptno","type","charge"), array($db->getDate(),$amount, $acc_amount, $receipt, "S", "0"), array("accountno"), array($account));

	}else{
		$db->_save("currentt", array("personalid","paydate","amount","acumulatedamount","receiptno","type","charge","accountno"),array($account,$db->getDate(),$amount, $acc_amount, $receipt, "S", "0",$account));
	}
	//save to hist table
	$db->_save("hist", array("personalid","paydate","amount","acumulatedamount","receiptno","type","charge","accountno"),array($account,$db->getDate(),$amount, $acc_amount, $receipt, "S", "0",$account));
	//save to frequent table
	if($db->_check("frequent",array("accountno", "user"), array($account, $user))){
		//update times
		$times = $db->_get("frequent",$db->_toString(array("accountno"),array($account)),"times");
		$times = $times + 1;
		$db->_update("frequent",array("times"), array($times), array("accountno"),array($account));
	}else{
		//add the account no
		$db->_save("frequent", array("accountno", "user", "times", "trans_date"),array($account,$user,"1",$db->getDate()));
	}
	//update repository
	$db->update_repository($amount,1);
	//update userfloat
	$db->update_user_float($user,$amount,1);
	//save transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Savings",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,"0","successful"));
	//save to user trace
	$db->_save("userstrace",array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),array($db->getDate(),$account,$user,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,"0","Savings","successful",$receipt));
	$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($account)),"acumulatedamount");
	if($bal == "null"){
		$bal = $db->_get("account",$db->_toString(array("accountno"),array($account)),"deposit");
	}
	//send message
	$message = "Cash Deposit of UGX ".$amount." on A/C: ".$account." was successfull. Balance: UGX ".$bal;
	$db->send_message($account,$message);
	//feedback (sendmessage here)
	$msg->success("Deposit Successful");
}
/////=======Withdraw==========///
if(isset($_POST['withdraw'])){
	$receipt = $_POST['receiptno'];
	$amount = $_POST['amount'];
	$charge = $_POST['charge'];
	$account = $_SESSION["account"];
	$float = $db->_get("systemusers",$db->_toString(array("username"),array($user)),"userFloat");
	$rmfloat = $float - $amount;
	if($rmfloat >= 0){
	//get last bal
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($account)),"acumulatedamount");
		if($bal == "null"){
			$bal = $db->_get("account",$db->_toString(array("accountno"),array($account)),"deposit");
		}
		$acc_amount = $bal - ($amount + $charge);
		$minAccountBal = $db->_get("settings",$db->_toString(array("field"),array("minimumAccountBalance")),"value");
		if($acc_amount >= $minAccountBal){		
	//update account balance
			if($db->_check("currentt",array("accountno"), array($account))){
				$db->_update("currentt",array("paydate","amount","acumulatedamount","receiptno","type","charge"), array($db->getDate(),$amount, $acc_amount, $receipt, "W", $charge), array("accountno"), array($account));

			}else{
				$db->_save("currentt", array("personalid","paydate","amount","acumulatedamount","receiptno","type","charge","accountno"),array($account,$db->getDate(),$amount, $acc_amount, $receipt, "W", $charge,$account));
			}
	//save to hist table
			$db->_save("hist", array("personalid","paydate","amount","acumulatedamount","receiptno","type","charge","accountno"),array($account,$db->getDate(),$amount, $acc_amount, $receipt, "W", $charge,$account));
	//save to frequent table
			if($db->_check("frequent",array("accountno", "user"), array($account, $user))){
		//update times
				$times = $db->_get("frequent",$db->_toString(array("accountno"),array($account)),"times");
				$times = $times + 1;
				$db->_update("frequent",array("times"), array($times), array("accountno"),array($account));
			}else{
		//add the account no
				$db->_save("frequent", array("accountno", "user", "times", "trans_date"),array($account,$user,"1",$db->getDate()));
			}
	//update repository
			$db->update_repository($amount,0,$charge);
	//update userfloat
			$db->update_user_float($user,$amount,0);
	//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Withdraws",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,$charge,"successful"));
	//save to user trace
			$db->_save("userstrace",array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),array($db->getDate(),$account,$user,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,$charge,"Withdraws","successful",$receipt));
	//feedback (sendmessage here)
			$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($account)),"acumulatedamount");
			if($bal == "null"){
				$bal = $db->_get("account",$db->_toString(array("accountno"),array($account)),"deposit");
			}
	//send message
			$message = "Cash Withdraw of UGX ".$amount." on A/C: ".$account." at a fee of UGX ".$charge." was successfull. Balance: UGX ".$bal;
			$db->send_message($account,$message);
			$msg->success("Withdraw Successful");
		}
		else{
	//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Withdraws",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,$charge,"Failed"));
			$ft =  $db->_get("systemusers",$db->_toString(array("username"),array($user)),"failedTransactions") + 1;
			$db->_update("systemusers", array("failedTransactions"),array($ft), array("username"), array($user));
			$msg->failed("Account Balance is Insuficient for this transaction");
		}
	}
	else{
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Withdraws",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$amount,$charge,"Failed"));
		$ft =  $db->_get("systemusers",$db->_toString(array("username"),array($user)),"failedTransactions") + 1;
		$db->_update("systemusers", array("failedTransactions"),array($ft), array("username"), array($user));
		$msg->failed("Your Float is Insuficient for this transaction");
	}
}

/////////Loan/////////////
if(isset($_POST['newloan'])){
	if($db->_check("loan",array("accountno","loanstatus"),array($_SESSION['account'],"unpaid"))){
		//display info
		$msg->failed("Member still has unpaid loan");
	}else{
		$account = $_SESSION['account'];
		$loanApplicationFees = $_POST['loanApplicationFees'];
		$loanAmount = $_POST['amount'];
		$interestRate = $_POST['interestRate'];
		$repaymentdate = $_POST['repaymentDate'];
		$dateTime = new DateTime($repaymentdate);
		$year = $dateTime->format('Y');
		$month = $dateTime->format('m');
		$day = $dateTime->format('d');
		$repaymentdate = $day."/".$month."/".$year." 12:00:00";
		$fineRate = $_POST['FineRate'];
		$receipt = $_POST['receiptNo'];
		$interest = ($interestRate / 100 )*$loanAmount;
		$repay_amount = $loanAmount + $interest;
		$fine = ($fineRate / 100 )*$loanAmount;
		$times = $db->get_loan_times($_SESSION['account']) + 1;	
		if($db->_save("loan",array("accountno", "loanamount", "loandate", "repaymentdate", "intrestrate", "intrest", "repaymentamount", "receiptno", "loanstatus", "fine", "times", "finerate", "loanFees"),array($_SESSION['account'],$loanAmount,$db->getDateNew(),$repaymentdate,$interestRate,$interest,$repay_amount,$receipt,"unpaid",$fine,$times,$fineRate,$loanApplicationFees))){
			if($db->_check("frequent",array("accountno", "user"), array($account, $user))){
		//update times
				$times = $db->_get("frequent",$db->_toString(array("accountno"),array($account)),"times");
				$times = $times + 1;
				$db->_update("frequent",array("times"), array($times), array("accountno"),array($account));
			}else{
		//add the account no
				$db->_save("frequent", array("accountno", "user", "times", "trans_date"),array($account,$user,"1",$db->getDate()));
			}
	//update repository
	//$db->update_repository($amount,0,0);
	//update userfloat
	//$db->update_user_float($user,$amount,0);
	//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"New Loan",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$loanAmount,$loanApplicationFees,"successful"));
	//save to user trace
			$db->_save("userstrace",array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),array($db->getDate(),$account,$user,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$loanAmount,$loanApplicationFees,"New Loan","successful",$receipt));
			//save to loan hist
			//send message
	$message = "New Loan application of UGX ".$loanAmount." on A/C: ".$account." with interest of UGX ".$interest." was successfull. Loan Balance: UGX ".$repay_amount;
	$db->send_message($account,$message);
			$msg->success("Loan added successfuly");

		}
		else{
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"New Loan",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$loanAmount,$loanApplicationFees,"Failed"));
			$msg->failed("Error; Please try again");
		}

	}
}
//Edit member
if(isset($_POST['edit-member'])){
	//Get Inputs
	$inputs = array(
		$_POST['surname'],
		$_POST['othernames'],
		$_POST['address'],
		$_POST['occupation'],
		$_POST['gender'],
		$_POST['nin'],
		$_POST['fees'],
		$_POST['contact'],
		$_POST['s1name'],
		$_POST['s1contact'],
		$_POST['s1nin'],
		$_POST['s2name'],
		$_POST['s2contact'],
		$_POST['s2nin'],
		$_SESSION['account']
	);
	if($db->_update("member",
		array("surname", "other_name", "address", "ocupation", "personalnin", "contact", "gender", "registrationfee"),
		array($inputs[0],$inputs[1],$inputs[2],$inputs[3],$inputs[5],$inputs[7],$inputs[4],$inputs[6]),
		array("accountno"),
		array($inputs[14])
	)){
		//update seconders
		$db->_update("account",
			array( "seconder1", "seconder1contact", "seconder1nin", "seconder2", "seconder2contact", "seconder2nin"),
			array($inputs[8],$inputs[9],$inputs[10],$inputs[11],$inputs[12],$inputs[13]),
			array("accountno"),
			array($inputs[14])
		);
	//Save to transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Edit Member",$inputs[14],$db->_get("member",$db->_toString(array("accountno"),array($inputs[14])),"surname"),"0","0","successful"));
	$msg->success("Member Edited Successfuly");
	
}
else{
		//Save to transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Edit Member",$inputs[14],$db->_get("member",$db->_toString(array("accountno"),array($inputs[14])),"surname"),"0","0","Failed"));
	$msg->failed("Error; Please try again");
}
}
//Dissmiss member
if(isset($_POST['dissmiss-member'])){
	//get the password 
	$accountno = $_SESSION['account'];
	$user_pass = $_POST['user_pass'];
	$user_pass = md5($user_pass);
	if($db->_check("systemusers",array("password","role"),array($user_pass,"Admin"))){
		if($db->_check("member",array("accountno"), array($accountno))){
			//get member details
			$surname =  $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname");
			$othernames = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"other_name");
			$address = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"address");
			$dob = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"birthdate");
			$ocupation = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"ocupation");
			$nin = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"personalnin");
			$contact = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"contact");
			$gender = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"gender");
			$fees = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"registrationfee");
			$accountno = $db->_get("member",$db->_toString(array("accountno"),array($accountno)),"accountno");
			if($db->_save("deleted",array("surname", "other_name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registratonfee", "accountno"),array($surname,$othernames,$address,$dob,$ocupation,$nin,$contact,$gender,$fees,$accountno))){
				//delete from member
				$db->_delete("member",$db->_toString(array("accountno"),array($accountno)));

				//delete from account
				$db->_delete("account",$db->_toString(array("accountno"),array($accountno)));
				//delete from loans
				$db->_delete("loan",$db->_toString(array("accountno"),array($accountno)));
				//Delete from shares
				$db->_delete("share",$db->_toString(array("accountno"),array($accountno)));
				//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Dismiss Member",$accountno,$db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname"),"0","0","Successful"));
				$msg->success("Member Dissmissed Successfuly");

			}
			else{
				//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Dismiss Member",$accountno,$db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname"),"0","0","Failed"));
				$msg->failed("Error; Please try again");
			}
		}
		else{
				//Save to transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Dismiss Member",$accountno,$db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname"),"0","0","Failed"));
			$msg->success("Account number does not exist");
		}
	}
	else{
		//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Dismiss Member",$accountno,$db->_get("member",$db->_toString(array("accountno"),array($accountno)),"surname"),"0","0","Failed"));
		$msg->failed("Invalid Password or Limited Rights to Dissmiss Member");
	}

}
//delete user
if(isset($_POST['delete-user'])){
	$user_pass = $_POST['user_pass'];
	$user_pass = md5($user_pass);
	$fullname = $db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname");
	if($db->_check("systemusers",array("password","role"),array($user_pass,"Admin"))){

		if($db->_delete("systemusers",$db->_toString(array("id"),array($_SESSION['id'])))){
		//Save to transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete User",$_SESSION['id'],$fullname,"0","0","Successful"));
			$msg->success("User Deleted Successfuly");
		}
		else{
		//Save to transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete User",$_SESSION['id'],$db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname"),"0","0","Failed"));
			$msg->failed("Error; Please try again");

		}
	}else{
	//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete User",$_SESSION['id'],$db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname"),"0","0","Failed"));
		$msg->failed("Invalid Password or Less Rights To Perform this Action");
	}

}
//add user
if(isset($_POST['add-user'])){
	//get inputs
	$inputs = array(
		$_POST['fullname'],
		$_POST['username'],
		$_POST['role'],
		$_POST['password'],
		$_POST['c_password']
	);
	if($inputs[3] == $inputs[4]){
		if($db->_check("systemusers",array("username"),array($inputs[1]))){
			$msg->failed("Sorry; Selected username is already in use!");
		}
		else{
			$pass = md5($_POST['password']);
			if($db->_save("systemusers",array("fullname", "username", "password", "role", "userFloat", "status", "succTransactions", "failedTransactions", "profile"),array(
				$inputs[0],
				ucfirst($inputs[1]),
				$pass,
				$inputs[2],
				"0",
				"open",
				"0",
				"0",
				"default.png"))){
				//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Add User",$inputs[1],$inputs[0],"0","0","Successful"));
				$msg->success("User Added Successfuly");
			}
			else{
				//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Add User",$inputs[1],$inputs[0],"0","0","Failed"));
				$msg->failed("Error; Please try again");
			}
		}
	}
	else{
		$msg->failed("Passwords do not match!");
	}
}

//save user edit profile
if(isset($_POST['save-edit--basic-profile'])){
	//get the role
	$id = $_SESSION['user_id'];
	$db_role = $db->_get("systemusers",$db->_toString(array("username"),array($user)),"role");
	if($db_role == $role || $role == "Admin"){
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		$db->_update("systemusers",
			array("fullname","role"),
			array($fullname,$role),
			array("ID"),
			array($id)
		);
		//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Edit User","N/A","N/A","0","0","Successful"));
		$msg->success("User Details Changed Successfuly");
	}
	else{
				//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Edit User","N/A","N/A","0","0","Failed"));
		$msg->failed("Less Rights To Perform This Transaction");
	}
}

if(isset($_POST['payback_loan'])){
	$total_due = $_POST['total_amount'];
	$paid_amount = $_POST['amount'];
	$account = $_SESSION['account'];
	$fine = $_POST['fine'];
	$receipt = $_POST['receiptno'];
	$balance = $total_due - $paid_amount;
	if($balance < 0){
		$msg->failed("The paid amount can not be greater than the amount Due!");
	}
	else if($balance == 0){
		$loanstatus = "paid";
		if($db->repay_loan($account, $paid_amount, $balance, $loanstatus,$fine,$receipt)){
			
			//save to frequent table
			if($db->_check("frequent",array("accountno", "user"), array($account, $user))){
		//update times
				$times = $db->_get("frequent",$db->_toString(array("accountno"),array($account)),"times");
				$times = $times + 1;
				$db->_update("frequent",array("times"), array($times), array("accountno"),array($account));
			}else{
		//add the account no
				$db->_save("frequent", array("accountno", "user", "times", "trans_date"),array($account,$user,"1",$db->getDate()));
			}
	//
	//update userfloat
			$db->update_user_float($user,$paid_amount,1);
	//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Loan Payment",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$paid_amount,"0","successful"));
	//save to user trace
			$db->_save("userstrace",array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),array($db->getDate(),$account,$user,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$paid_amount,"0","Loan Payment","successful",$receipt));
			$loanCond = "`accountno` = '".$account."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
			$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
			if($loanBal == "null"){
				$loanBal = 0;
			}
	//send message
			$message = "Loan Repayment of UGX ".$paid_amount." on A/C: ".$account." was successfull. Loan Balance: UGX ".$loanBal;
			$db->send_message($account,$message);
			$msg->success("Loan Payment Successful");
		}
		else{ 
			//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Loan Payment",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$paid_amount,"0","Failed"));
			$msg->failed("Error; Please try again");
		}
	}
	else{
		$loanstatus = "running";
		if($db->repay_loan($account, $paid_amount, $balance, $loanstatus,$fine,$receipt)){
					//save to frequent table
			if($db->_check("frequent",array("accountno", "user"), array($account, $user))){
		//update times
				$times = $db->_get("frequent",$db->_toString(array("accountno"),array($account)),"times");
				$times = $times + 1;
				$db->_update("frequent",array("times"), array($times), array("accountno"),array($account));
			}else{
		//add the account no
				$db->_save("frequent", array("accountno", "user", "times", "trans_date"),array($account,$user,"1",$db->getDate()));
			}
	//
	//update userfloat
			$db->update_user_float($user,$paid_amount,1);
	//save transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Loan Payment",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$paid_amount,"0","successful"));
	//save to user trace
			$db->_save("userstrace",array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno"),array($db->getDate(),$account,$user,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),$paid_amount,"0","Loan Payment","successful",$receipt));
			$loanCond = "`accountno` = '".$account."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
			$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
			if($loanBal == "null"){
				$loanBal = 0;
			}
	//send message
			$message = "Loan Repayment of UGX ".$paid_amount." on A/C: ".$account." was successfull. Loan Balance: UGX ".$loanBal;
			$db->send_message($account,$message);

			$msg->success("Loan Payment Successful");
		}
		else{
			$msg->failed("Error; Please try again");
		}
	}
}

//Cash in user
if(isset($_POST['cash-in-user'])){
	$user_pass = $_POST['user_pass'];
	$user_pass = md5($user_pass);
	if(empty($_POST['cashinamount'])){
		$amount  = $db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"userFloat");
	}
	else{
		$amount = $_POST['cashinamount'];
	}
	$real_amount = $db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"userFloat");
	if($db->_check("systemusers",array("password","role"),array($user_pass,"Admin"))){
		$balance = $real_amount - $amount;
		if($balance < 0){
			$msg->failed("The checkin amount is greater than the user float");
		}
		else{
			if($db->_update("systemusers",
				array("userFloat","succTransactions","failedTransactions"),
				array($balance,"0","0"),
				array("id"),
				array($_SESSION['id'])
			)){
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"User Cash In",$_SESSION['id'],$db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname"),$amount,"0","Successful"));
			$msg->success("User Cash In Successful");
		}
		else{
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"User Cash In",$_SESSION['id'],$db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname"),$amount,"0","Failed"));
			$msg->failed("Error; Please try again");
		}
	}

}
else{
		//Save to transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"User Cash In",$_SESSION['id'],$db->_get("systemusers",$db->_toString(array("id"),array($_SESSION['id'])),"fullname"),$amount,"0","Failed"));
	$msg->failed("Invalid Password or Less Rights To Perform this Action");
}
}

//Delete Loan//
if(isset($_POST['delete-load-details'])){
	$user_pass = $_POST['user_pass'];
	$user_pass = md5($user_pass);
	$account = $_SESSION['account'];
	if($db->_check("systemusers",array("password","role"),array($user_pass,"Admin"))){		
		if($db->_delete("loan",$db->_toString(array("accountno"),array($account)))){
			$db->_delete("payment",$db->_toString(array("accountno"),array($account)));
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete Loan Details",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),"N/A","0","Successful"));
			$msg->success("All Loan Details Deleted!");
		}
		else{
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete Loan Details",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),"N/A","0","Failed"));
			$msg->failed("Error; Please try again");

		}
	}
	else{
		//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Delete Loan Details",$account,$db->_get("member",$db->_toString(array("accountno"),array($account)),"surname"),"N/A","0","Failed"));
		$msg->failed("Invalid Password or Less Rights To Perform this Action");

	}
}

//Delete member
if(isset($_POST['completely-delete-member'])){
	$user_pass = $_POST['user_pass'];
	$user_pass = md5($user_pass);
	$account = $_SESSION['account'];
	$name = $db->_get("deleted",$db->_toString(array("accountno"),array($account)),"surname");
	if($db->_check("systemusers",array("password","role"),array($user_pass,"Admin"))){		
		if($db->_delete("deleted",$db->_toString(array("accountno"),array($account)))){
		//save to transactions			
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Completely Delete Member",$account,$name,"N/A","0","Successful"));
			$msg->success("Member Deleted!");
		}
		else{
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Completely Delete Member",$account,$name,"N/A","0","Failed"));
			$msg->failed("Error; Please try again!");

		}
	}
	else{
		//Save to transactions
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Completely Delete Member",$account,$name,"N/A","0","Failed"));
		$msg->failed("Invalid Password or Less Rights To Perform this Action");

	}
}

//Edit values
if(isset($_POST['save_edit_values'])){
	$accountno = $_SESSION['account']; 
	$field = $_POST['filed'];
	$value  = $_POST['value'];
	if($field == "acumulatedamount"){
		//check the wether savings have been done
		$bal = $db->_get("currentt",$db->_toString(array("accountno"),array($accountno)),"acumulatedamount");
		if($bal == "null"){
			$msg->success("The first option");
			//edit deposit
			if($db->_update("account",array("deposit"),array($value),array("accountno"),array($accountno))){
				$msg->success("Account Balance Updated!");
			}
			else{
				$msg->failed("Sorry; Error has happened!, Please try again");
			}

		}
		else{
			//edit accumulated amount
			if($db->_update("currentt",array("acumulatedamount"),array($value),array("accountno"),array($accountno))){
				$msg->success("Account Balance Updated!");
			}
			else{
				$msg->failed("Sorry; Error has happened!, Please try again");
			}

		}
	}
	elseif($field == "repaymentamount"){
		$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
		$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
		$times = $db->_get("loan",$loanCond,"times");
		if($loanBal == "null"){
			$msg->failed("This member has no loan!");
		}
		else{
			//edit repayment ammount
			if($db->_update("loan",array("repaymentamount"),array($value),array("accountno","times"),array($accountno,$times))){
				$msg->success("Loan Balance Updated!");
			}
			else{
				$msg->failed("Sorry; Error has happened!, Please try again");
			}
		}
	}
	else if($field == "contact"){
		//edit member account
		if(strlen($value) < 10 || strlen($value) > 11){
			$msg->failed("The contact is in invalid format!");
		}
		else{
			if($db->_update("member",array("contact"),array($value),array("accountno"),array($accountno))){
				$msg->success("Contact Updated!");
			}
			else{
				$msg->failed("Sorry; Error has happened!, Please try again");
			}
		}
	}
}
//Change loan repayment date
if(isset($_POST['save_change_loan_date'])){
	$accountno = $_SESSION['account']; 
	$loanCond = "`accountno` = '".$accountno."' AND (`loanstatus` = 'unpaid' or `loanstatus` = 'running')";
	$loanBal = $db->_get("loan",$loanCond,"repaymentamount");
	$times = $db->_get("loan",$loanCond,"times");
	if($loanBal == "null"){
		$msg->failed("This member has no loan!");
	}else{
		$repaymentdate = $_POST['repaymentDate'];
		$dateTime = new DateTime($repaymentdate);
		$year = $dateTime->format('Y');
		$month = $dateTime->format('m');
		$day = $dateTime->format('d');
		$repaymentdate = $day."/".$month."/".$year." 12:00:00";
		if($db->_update("loan",array("repaymentdate"),array($repaymentdate),array("accountno","times"),array($accountno,$times))){
			$msg->success("Loan Repayment Date Updated!");
		}
		else{
			$msg->failed("Sorry; Error has happened!, Please try again");
		}

	}
}

///add shares//
if(isset($_POST['add-share'])){
	$account = $_SESSION['account'];
	$amount = $_POST['amount'];
	$name = $db->_get("member",$db->_toString(array("accountno"),array($account)),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($account)),"other_name");
	if($db->_check("share",array("accountno"),array($account))){
		//get old shares
		$old_shares = $db->_get("share",$db->_toString(array("accountno"),array($account)),"shares");
		$new_sahres = round($amount / 10000, 2);
		$new_sahres = $old_shares + $new_sahres;
		//get new amount 
		$new_amount = $new_sahres * 10000;
		if($db->_update("share",
			array("shares","amount"),
			array($new_sahres,$new_amount),
			array("accountno"),
			array($account)
		)){
			$db->update_user_float($user,$amount,1);
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Add Shares",$account,$name,$amount,"0","Successful"));
		$msg->success("Shares added successfuly");
	}
	else{
		$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Add Shares",$account,$name,$amount,"0","Failed"));
		$msg->failed("Error; Please try again");
	}
}
else{
		//Save to transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Add Shares",$account,$name,$amount,"0","Failed"));
	$msg->failed("Account not found!");
}

}

//Remove share
if(isset($_POST['remove-share'])){
	$account = $_SESSION['account'];
	$amount = $_POST['amount'];
	$name = $db->_get("member",$db->_toString(array("accountno"),array($account)),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($account)),"other_name");
	if($db->_check("share",array("accountno"),array($account))){
		//get old shares
		$old_shares = $db->_get("share",$db->_toString(array("accountno"),array($account)),"shares");
		$new_sahres = round($amount / 10000, 2);
		$new_sahres = $old_shares - $new_sahres;
		if($new_sahres < 0){
			$msg->failed("Insuficient shares for this transaction");
		}
		else{
		//get new amount 
			$new_amount = $new_sahres * 10000;
			if($db->_update("share",
				array("shares","amount"),
				array($new_sahres,$new_amount),
				array("accountno"),
				array($account)
			)){
				$db->update_user_float($user,$amount,1);
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Remove Shares",$account,$name,$amount,"0","Successful"));
			$msg->success("Shares removed successfuly");
		}
		else{
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Remove Shares",$account,$name,$amount,"0","Failed"));
			$msg->failed("Error; Please try again");
		}
	}
}
else{
		//Save to transactions
	$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Remove Shares",$account,$name,$amount,"0","Failed"));
	$msg->failed("Account not found!");
}
}

//Transfer shares
if(isset($_POST['transfer-share'])){
	$from_account = $_SESSION['account'];
	$to_account = $_POST['to_account'];
	$amount = $_POST['amount'];	
	$from_name = $db->_get("member",$db->_toString(array("accountno"),array($from_account)),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($from_account)),"other_name");
	if($db->_check("member",array("accountno"),array($to_account))){
		$to_name = $db->_get("member",$db->_toString(array("accountno"),array($to_account)),"surname")." ".$db->_get("member",$db->_toString(array("accountno"),array($to_account)),"other_name");
		//Check sahres from account
		$from_shares = $db->_get("share",$db->_toString(array("accountno"),array($from_account)),"shares");
		$transit_sahres = round($amount / 10000, 2);
		$from_new_shares = $from_shares - $transit_sahres;
		if($from_new_shares < 0){
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Transfer Shares",$from_account." to ".$to_account,$from_name." to ".$to_name,$amount,"0","Failed"));
			$msg->failed("Insuficient shares for this transfer");
		}
		else{
			//remove shares from from account
			$new_from_amount = $from_new_shares * 10000;
			if($db->_update("share",
				array("shares","amount"),
				array($from_new_shares,$new_from_amount),
				array("accountno"),
				array($from_account)
			)){
			//Add shares to the new account
			//get old too account shares
				$to_shares = $db->_get("share",$db->_toString(array("accountno"),array($to_account)),"shares");
			$new_to_shares = $to_shares + $transit_sahres;
			$to_share_amount = $new_to_shares * 10000;
			if($db->_check("share", array("accountno"),array($to_account))){
				//update shares
				$db->_update("share",array("shares","amount"),array($new_to_shares,$to_share_amount),array("accountno"),array($to_account));
					//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Transfer Shares",$from_account." to ".$to_account,$from_name." to ".$to_name,$amount,"0","successful"));
				$msg->success("Shares transfer successful");
			}
			else{
				//insert shares
				$db->_save("share",array("accountno","shares","amount"),array($to_account,$new_to_shares,$to_share_amount));
				//Save to transactions
				$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Transfer Shares",$from_account." to ".$to_account,$from_name." to ".$to_name,$amount,"0","successful"));
				$msg->success("Shares transfer successful");

			}

		}else{
			//Save to transactions
			$db->_save("transactions", array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),array($user,$db->getDate(),"Transfer Shares",$from_account." to ".$to_account,$from_name." to ".$to_name,$amount,"0","Failed"));
			$msg->failed("Account not found!");
		}

	}
}
else{
	$msg->failed("The account number to transfer to is invalid!");
}	
}

//Import Action Members
if(isset($_POST["import_data_members"])){
	unset($_SESSION['upload-data']);
	//making sure the file format is not invalid
	$file_name = pathinfo($_FILES['file']['name']);
	
	$ext = $file_name['extension'];
	if($ext != "csv"){
		$msg->failed("Please select a CSV file for this operation");
	}else{
		//get the file contents
		$data = $_FILES['file']['tmp_name'];
		$data = array_map('str_getcsv', file($data));
		$table = $_POST['table'];
		$_SESSION['table'] = $table;
		$i = 0;
		$test_value = $data[0][0];
		if($test_value == "surname"){
			foreach ($data as $row => $row_a){			
				$indidual_row[$i++] = array($row_a[0],$row_a[1],$row_a[2],$row_a[3],$row_a[4],$row_a[5],$row_a[6],$row_a[7],$row_a[8],$row_a[9],$row_a[10],$row_a[11],$row_a[12],$row_a[13],$row_a[14],$row_a[15],$row_a[16],$row_a[17],$row_a[18]);					  		  	  
			}
			$table_head = $indidual_row[0];
			$m = 1;
			for($i=0;$i<count($data)-1;$i++){
				$table_body[$i] = $indidual_row[$m++];
			}
			$_SESSION['upload-data'] = $table_body;
			$data_table = $int->_table("Extracted Members From the File",$table_head,$table_body);
			$msg->success("All data has been loaded in a temp file, Please confirm the import");
		}
		else{
			$msg->failed("Please select the right template/file for members");
		}

	}
}

//Import action for user transactions
if(isset($_POST['import_data_transactions'])){
	unset($_SESSION['upload-data']);
	//making sure the file format is not invalid
	$file_name = pathinfo($_FILES['file']['name']);
	
	$ext = $file_name['extension'];
	if($ext != "csv"){
		$msg->failed("Please select a CSV file for this operation");
	}else{
		//get the file contents
		$data = $_FILES['file']['tmp_name'];
		$data = array_map('str_getcsv', file($data));
		$table = $_POST['table'];
		$_SESSION['table'] = $table;
		$i = 0;
		$test_value = $data[0][0];
		if($test_value != "datetime"){
			$msg->failed("Please select the right template/file for user transactions");
		}
		else{
			foreach ($data as $row => $row_a){
				$indidual_row[$i++] = array($row_a[0],$row_a[1],$row_a[2],$row_a[3],$row_a[4],$row_a[5],$row_a[6],$row_a[7],$row_a[8]);		  		  	  
			}
			$table_head = $indidual_row[0];
			$m = 1;
			for($i=0;$i<count($data)-1;$i++){
				$table_body[$i] = $indidual_row[$m++];
			}		
			$_SESSION['upload-data'] = $table_body;	
			$data_table = $int->_table("Extracted User Transactions From the File",$table_head,$table_body);
			$msg->success("All data has been loaded in a temp file, Please confirm the import");
		}
	}

}

//Import action for members transactions
if(isset($_POST['import_data_hist'])){
	unset($_SESSION['upload-data']);
	//making sure the file format is not invalid
	$file_name = pathinfo($_FILES['file']['name']);
	
	$ext = $file_name['extension'];
	if($ext != "csv"){
		$msg->failed("Please select a CSV file for this operation");
	}else{
		//get the file contents
		$data = $_FILES['file']['tmp_name'];
		$data = array_map('str_getcsv', file($data));
		$table = $_POST['table'];
		$_SESSION['table'] = $table;
		$i = 0;
		$test_value = $data[0][0];
		if($test_value != "personalid"){
			$msg->failed("Please select the right template/file for members transactions");
		}
		else{
			foreach ($data as $row => $row_a){
				$indidual_row[$i++] = array($row_a[0],$row_a[1],$row_a[2],$row_a[3],$row_a[4],$row_a[5],$row_a[6],$row_a[7]);		  		  	  
			}
			$table_head = $indidual_row[0];
			$m = 1;
			for($i=0;$i<count($data)-1;$i++){
				$table_body[$i] = $indidual_row[$m++];
			}	

			
			$_SESSION['upload-data'] = $table_body;	
			$data_table = $int->_table("Extracted Member Transactions From the File",$table_head,$table_body);
			$msg->success("All data has been loaded in a temp file, Please confirm the import");
		}
	}

}
//Import Members Balances
if(isset($_POST['import_data_balances'])){
	unset($_SESSION['upload-data']);
	//making sure the file format is not invalid
	$file_name = pathinfo($_FILES['file']['name']);
	
	$ext = $file_name['extension'];
	if($ext != "csv"){
		$msg->failed("Please select a CSV file for this operation");
	}else{
		//get the file contents
		$data = $_FILES['file']['tmp_name'];
		$data = array_map('str_getcsv', file($data));
		$table = $_POST['table'];
		$_SESSION['table'] = $table;
		$i = 0;
		$test_value = $data[0][6];
		if($test_value != "charge"){
			$msg->failed("Please select the right template/file for members net balances transactions");
		}
		else{
			foreach ($data as $row => $row_a){
				$indidual_row[$i++] = array($row_a[0],$row_a[1],$row_a[2],$row_a[3],$row_a[4],$row_a[5],$row_a[6],$row_a[7]);		  		  	  
			}
			$table_head = $indidual_row[0];
			$m = 1;
			for($i=0;$i<count($data)-1;$i++){
				$table_body[$i] = $indidual_row[$m++];
			}	

			
			$_SESSION['upload-data'] = $table_body;	
			$data_table = $int->_table("Extracted Net Member Balances From the File",$table_head,$table_body);
			$msg->success("All data has been loaded in a temp file, Please confirm the import");
		}
	}

}
//Import Members Basic Loan Details
if(isset($_POST['import_data_loan'])){
	unset($_SESSION['upload-data']);
	//making sure the file format is not invalid
	$file_name = pathinfo($_FILES['file']['name']);
	
	$ext = $file_name['extension'];
	if($ext != "csv"){
		$msg->failed("Please select a CSV file for this operation");
	}else{
		//get the file contents
		$data = $_FILES['file']['tmp_name'];
		$data = array_map('str_getcsv', file($data));
		$table = $_POST['table'];
		$_SESSION['table'] = $table;
		$i = 0;
		$test_value = $data[0][1];
		if($test_value != "loanamount"){
			$msg->failed("Please select the right template/file for members loan balances");
		}
		else{
			foreach ($data as $row => $row_a){
				$indidual_row[$i++] = array($row_a[0],$row_a[1],$row_a[2],$row_a[3],$row_a[4],$row_a[5],$row_a[6],$row_a[7],$row_a[8],$row_a[9],$row_a[10],$row_a[11],$row_a[12]);		  		  	  
			}
			$table_head = $indidual_row[0];
			$m = 1;
			for($i=0;$i<count($data)-1;$i++){
				$table_body[$i] = $indidual_row[$m++];
			}	

			
			$_SESSION['upload-data'] = $table_body;	
			$data_table = $int->_table("Extracted Member Loan Balances From the File",$table_head,$table_body);
			$msg->success("All data has been loaded in a temp file, Please confirm the import");
		}
	}

}


//Confirm The Data Import
if(isset($_POST['confirm_import_data'])){
	ini_set('max_execution_time', 700);
	$table = $_SESSION['table'];
	$members = $_SESSION['upload-data'];
	if($table == "member"){
		$member_fields = array("surname", "other_name", "address", "birthdate", "ocupation", "personalnin", "contact", "gender", "registrationfee", "accountno");
		$account_fields = array("personalid", "deposit", "dateopened", "seconder1", "seconder1contact", "seconder1nin", "seconder2", "seconder2contact", "seconder2nin", "accountno");
		$shares_fields = array("accountno", "shares", "amount");
		foreach ($members as $member => $members_a) {
 		//check if there is a similar aaccount number
			$accountno = $members_a[9];
			if($db->_check("member",array("accountno"),array($accountno))){
				$accountno = $db->generate_account_number("Member");
			}
 		//register the member
			$inputs = array(
				$members_a[0],
				$members_a[1],
				$members_a[2],
				$members_a[4],
				"Member",
				$members_a[7],
				$members_a[3],
				$members_a[5],
				$members_a[8],
				"0".$members_a[6],
				$members_a[13],
				"0".$members_a[14],
				$members_a[15],
				$members_a[16],
				"0".$members_a[17],
				$members_a[18],
				$accountno,
				$members_a[11]
			);

			if($db->_save("member", $member_fields,
				array($inputs[0],$inputs[1],$inputs[2],$inputs[6],$inputs[3],$inputs[7],$inputs[9],$inputs[5],$inputs[8],$inputs[16]))){			
			}
			//Save to acount			
		$db->_save("account",$account_fields,
			array($inputs[7],$inputs[17],$db->getDate(),$inputs[10],$inputs[11],$inputs[12],$inputs[13],$inputs[14],$inputs[15],$inputs[16]));
		//Save to sahres
		$shares = round($inputs[8]/10000, 2);
		$db->_save("share",$shares_fields,
			array($inputs[16],$shares,$inputs[8]));

		//Save to share hist
		$db->_save("share_hist", 
			array("date", "type", "shares", "accountno"),
			array($db->getDate(),"B",$shares,$inputs[16]));
		$db->update_repository($inputs[17],1);
		
	}
 	//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Importing Members","Bulk Numbers","N/A","N/A","0","successful"));
	$msg->success("Members import successful");

}
else if($table == "userstrace"){
	$transactions = $_SESSION['upload-data'];
	$user_trans_fileds = array("datetime", "accountno", "user", "accountname", "amount", "charge", "type", "status", "receiptno");
	foreach ($transactions as $transaction => $transaction_a){
		$date = $transaction_a[0];
		$sec = strtotime($date);
		$newdate = date ("Y-m-d H:i", $sec); 		
		$input = array($newdate,$transaction_a[1],$transaction_a[2],$transaction_a[3],$transaction_a[4],$transaction_a[5],$transaction_a[6],$transaction_a[7],$transaction_a[8]);
		$db->_save("userstrace",$user_trans_fileds,$input);
	}

 		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Importing User Transactions","Bulk Numbers","N/A","N/A","0","successful"));
	$msg->success("User Transactions import successful");
}
else if($table == "hist"){
	$hist = $_SESSION['upload-data'];
	$hist_fields = array("personalid", "paydate", "amount", "acumulatedamount", "receiptno", "type", "accountno", "charge");
	foreach ($hist as $history => $history_a){		
		$input = array($history_a[0],$history_a[1],$history_a[2],$history_a[3],$history_a[4],$history_a[5],$history_a[6],$history_a[7]);
		$db->_save("hist",$hist_fields,$input);
	}
 		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Importing Member Transactions","Bulk Numbers","N/A","N/A","0","successful"));
	$msg->success("User Transactions import successful");

}
else if($table == "currentt"){
	$hist = $_SESSION['upload-data'];
	$currentt_fields = array("personalid", "paydate", "amount", "acumulatedamount", "receiptno", "type", "charge", "accountno");
	foreach ($hist as $history => $history_a){		
		$input = array($history_a[0],$history_a[1],$history_a[2],$history_a[3],$history_a[4],$history_a[5],$history_a[6],$history_a[7]);
		$db->_save("currentt",$currentt_fields,$input);
	}
 		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Importing Member Balances","Bulk Numbers","N/A","N/A","0","successful"));
	$msg->success("Member Balances import successful");

}
else if($table == "loan"){
	$loans = $_SESSION['upload-data'];
	$loan_fields = array("accountno", "loanamount", "loandate", "repaymentdate", "intrestrate", "intrest", "repaymentamount", "receiptno", "loanstatus", "fine", "times", "finerate", "loanFees");
	foreach ($loans as $loan => $loan_a){	
	    $loanDate = $loan_a[2]." 12:00:00";
	    $repayDate = $loan_a[3]." 12:00:00";	
		$input = array($loan_a[0],$loan_a[1],$loanDate,$repayDate,$loan_a[4],$loan_a[5],$loan_a[6],$loan_a[7],$loan_a[8],$loan_a[9],$loan_a[10],$loan_a[11],$loan_a[12]);
		$db->_save($table,$loan_fields,$input);
	}
 		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Importing Member Loan Balances","Bulk Numbers","N/A","N/A","0","successful"));
	$msg->success("Member Loan Balances import successful");


}
else{
 	//other tables
}
}

////////Cash in flows//////////////
if(isset($_POST['add_cash_inflow'])){
	$amount = $_POST['amount'];
	$description = $_POST['description'];
	if($db->_save("finance",array("date", "type", "description", "amount", "user"),array($db->getDate(),"cashinflow",$description,$amount,$user))){
			//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Cashinflow Addition","N/A","N/A",$amount,"0","successful"));
	$msg->success("Cashinflow Registeration successful");

	}
	else{
		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Cashinflow Addition","N/A","N/A",$amount,"0","Failed"));
	$msg->failed("Cashinflow Registeration Failed, Please try again");

	}
}
////////Cash out flows//////////////
if(isset($_POST['add_cash_outflow'])){
	$amount = $_POST['amount'];
	$description = $_POST['description'];
	if($db->_save("finance",array("date", "type", "description", "amount", "user"),array($db->getDate(),"cashoutflow",$description,$amount,$user))){
			//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Cashoutflow Addition","N/A","N/A",$amount,"0","successful"));
	$msg->success("Cashoutflow Registeration successful");

	}
	else{
		//Save to logs
	$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Cashoutflow Addition","N/A","N/A",$amount,"0","Failed"));
	$msg->failed("Cashoutflow Registeration Failed, Please try again");
	}
}

//Bank///
if(isset($_POST['add_bank'])){
	$pic_name = pathinfo($_FILES['logo']['name']);
	$ext = $pic_name['extension'];
	$size = $_FILES['logo']['size'];
	if($db->_image_check($ext, $size)){
		$image = $_FILES['logo']['name'];
		$name = $_POST['name'];
		$branch = $_POST['main-brach'];
		$accountno = $_POST['accountno'];
		$balance =  $_POST['amountBalance'];
		if($db->_check("bank",array("accountno"),array($accountno))){
			$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Adding Bank Details",$accountno,$name,$balance,"0","Failed"));
			$msg->failed("Sorry; the account number already exists");

		}
		else{
			//save the bank
			if($db->_save("bank",array("name", "accountno", "date", "branch", "logo", "balance"),array($name,$accountno,$db->getDate(),$branch,$image,$balance))){
				//upload the image
				move_uploaded_file($_FILES['logo']['tmp_name'],"../assets/img/bank/".basename($_FILES['logo']['name']));
				$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Adding Bank Details",$accountno,$name,$balance,"0","Successful"));
			$msg->success("Bank Saved Successfuly");

			}
			else{
				$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Adding Bank Details",$accountno,$name,$balance,"0","Failed"));
			$msg->failed("Error; please try again");

			}

		}

	}
	else{
		$msg->failed("The image is too large or file format is unsupported");
	}
}
//deposit bank
if(isset($_POST['add_bank_deposit'])){
	$account = $_POST['accountno'];
	$amount = $_POST['amount'];
	$trans_date = $_POST['trans_date'];	
	$branch = $db->_get("bank",$db->_toString(array("accountno"),array($account)),"branch");
	$bal = $db->_get("bank",$db->_toString(array("accountno"),array($account)),"balance");
	$new_amount = $amount + $bal;
	if($db->_save("bank_transactions",array("date", "type", "amount", "accountno", "trans_branch", "trans_date", "balance"),array($db->getDate(),"Deposit",$amount,$account,$branch,$trans_date,$new_amount))){
		$db->_update("bank",array("balance"),array("$new_amount"),array("accountno"),array("$account"));
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Bank Deposit",$account,$db->_get("bank",$db->_toString(array("accountno"),array($account)),"name"),$amount,"0","Successful"));
			$msg->success("Bank Deposit recorded successfuly");
	}
	else{
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Bank Deposit",$account,$db->_get("bank",$db->_toString(array("accountno"),array($account)),"name"),$amount,"0","Failed"));
			$msg->failed("Error; please try again");

	}
}
//deposit withdraw
if(isset($_POST['add_bank_withdraw'])){
	$account = $_POST['accountno'];
	$amount = $_POST['amount'];
	$trans_date = $_POST['trans_date'];	
	$branch = $db->_get("bank",$db->_toString(array("accountno"),array($account)),"branch");
	$bal = $db->_get("bank",$db->_toString(array("accountno"),array($account)),"balance");
	$new_amount = $bal - $amount;
	if($new_amount < 0){
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Bank Withdraw > Insuficient balance",$account,$db->_get("bank",$db->_toString(array("accountno"),array($account)),"name"),$amount,"0","Failed"));
			$msg->failed("Insuficient amount on the account");
	}
	else{
	if($db->_save("bank_transactions",array("date", "type", "amount", "accountno", "trans_branch", "trans_date", "balance"),array($db->getDate(),"Withdraw",$amount,$account,$branch,$trans_date,$new_amount))){
		$db->_update("bank",array("balance"),array("$new_amount"),array("accountno"),array("$account"));
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Bank Withdraw",$account,$db->_get("bank",$db->_toString(array("accountno"),array($account)),"name"),$amount,"0","Successful"));
			$msg->success("Bank Withdraw recorded successfuly");
	}
	else{
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"Bank Withdraw",$account,$db->_get("bank",$db->_toString(array("accountno"),array($account)),"name"),$amount,"0","Failed"));
			$msg->failed("Error; please try again");

	}
}
}

//SYSTEM SETTINGS//
if(isset($_POST['set_account_prefix'])){
	$prefix = strtoupper($_POST['prefix']);
	$prefix = $db->prepareData($prefix);
	if($db->_check("settings",array("field"),array("accountNumberPrefix"))){
		$db->_update("settings",array("value"),array($prefix),array("field"),array("accountNumberPrefix"));
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"A/C Prefix Change","N/A","N/A","N/A","0","Successful"));
			$msg->success("Prefix changed successfuly");
	}
	else{
		$db->_save("settings",array("field","value"),array("accountNumberPrefix",$prefix));
		$db->_save("transactions", 
		array("user", "trans_date", "trans_type", "accountno", "accountname", "trans_amount", "charge", "trans_status"),
		array($user,$db->getDate(),"A/C Prefix Change","N/A","N/A","N/A","0","Successful"));
			$msg->success("Prefix saved successfuly");

	}
}

///Monthly payment
if(isset($_POST['save_monthly_payment'])){
	$monthlypay = $_POST['monthlypayment'];
	if($db->_check("settings",array("field"),array("monthlyPayment"))){
		$db->_update("settings",array("value"),array($monthlypay),array("field"),array("monthlyPayment"));
	}
	else{
		$db->_save("settings",array("field","value"),array("monthlyPayment",$monthlypay));
	}
	$msg->success("Monthly Payment Saved Successfuly");
}

//Efect monthly payments
if(isset($_POST['activate_monthly_payment'])){
	//put the dates function here
	$db->monthly_payments();
	echo "<meta http-equiv='refresh' content='0; url=../home/index.php?page=monthly-payment'>";
	$msg->success("Monthly Payment Effected Successfuly");
}
//minimum account balance
if(isset($_POST['save_minimum_account_bal'])){
	$minAmount = $_POST['minimumBalance'];
	if($db->_check("settings",array("field"),array("minimumAccountBalance"))){
		$db->_update("settings",array("value"),array($minAmount),array("field"),array("minimumAccountBalance"));
	}
	else{
		$db->_save("settings",array("field","value"),array("minimumAccountBalance",$minAmount));
	}
	$msg->success("Monthly minimumAccountBalance Saved Successfuly");
}
?>